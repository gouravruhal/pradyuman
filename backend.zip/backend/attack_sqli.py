import asyncio
import difflib
from urllib.parse import urlparse, parse_qs, urlencode, urlunparse
from zap_client import zap_client


SQLI_PAYLOADS = [
    "'",
    "' OR '1'='1",
    "\" OR \"1\"=\"1",
    "'--",
    "' OR 1=1--",
]


def inject_params(url, payload):
    parsed = urlparse(url)
    params = parse_qs(parsed.query)

    if not params:
        return None

    injected = {}
    for k in params:
        injected[k] = payload

    new_query = urlencode(injected, doseq=True)

    return urlunparse((
        parsed.scheme,
        parsed.netloc,
        parsed.path,
        parsed.params,
        new_query,
        parsed.fragment
    ))


def response_difference(a, b):
    return difflib.SequenceMatcher(None, a, b).ratio()


async def test_sqli(url, findings):

    injected_urls = []

    for payload in SQLI_PAYLOADS:
        injected = inject_params(url, payload)
        if injected:
            injected_urls.append(injected)

    if not injected_urls:
        return

    async with zap_client() as client:

        try:
            normal = await client.get(url)
            normal_text = normal.text[:5000]
        except:
            return

        for test_url in injected_urls:

            try:
                r = await client.get(test_url)
                diff = response_difference(normal_text, r.text[:5000])

                # significant response change
                if diff < 0.85:
                    findings.append({
                        "type": "SQL Injection",
                        "url": url,
                        "payload": test_url,
                        "confidence": "high"
                    })
                    return

            except:
                pass
