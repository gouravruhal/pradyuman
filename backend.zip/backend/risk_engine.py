import math
import logging
from collections import Counter
from typing import List, Dict, Optional


SEVERITY_WEIGHTS = {
    "critical": 10.0,
    "high": 7.5,
    "medium": 4.5,
    "low": 2.0,
    "info": 0.5
}


TECH_WEIGHT = 0.6
GRC_WEIGHT = 0.4

logger = logging.getLogger("RiskEngine")

def normalize_severity(s: str) -> str:
    """Standardizes severity strings for mapping."""
    if not s:
        return "info"
    return s.lower().strip()

def calculate_risk_score(findings: List[Dict], policy_score: float = 100.0) -> float:
    """
    Fuses Technical Findings and Policy Maturity into a 0-10 GRC Posture Index.
    
    Inputs:
    - findings: List of finding dictionaries from the scanner.
    - policy_score: 0-100 score from the AI Policy Auditor.
    """
    

    if not findings:
        tech_posture = 10.0 
    else:
        counts = Counter()
        for f in findings:
            sev = normalize_severity(f.get("severity"))
            counts[sev] += 1

        # Calculate weighted technical debt
        weighted_total = sum(
            counts[sev] * SEVERITY_WEIGHTS.get(sev, 0.5)
            for sev in counts
        )

        risk_density = weighted_total / 30.0
        tech_posture = 10.0 * math.exp(-risk_density)


    compliance_posture = max(0.0, min(policy_score / 10.0, 10.0))

    final_posture_index = (tech_posture * TECH_WEIGHT) + (compliance_posture * GRC_WEIGHT)

    logger.info(f"Fusion Complete - Tech: {tech_posture:.2f}, GRC: {compliance_posture:.2f}")

    return round(max(0.1, min(final_posture_index, 10.0)), 2)

if __name__ == "__main__":
    sample_findings = [
        {"severity": "Critical", "title": "SQL Injection"},
        {"severity": "Medium", "title": "Missing Header"}
    ]

    print(f"Final GRC Posture Index: {calculate_risk_score(sample_findings, 80.0)}")