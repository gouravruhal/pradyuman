import os
from datetime import datetime
from reportlab.lib.pagesizes import A4
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Image
from reportlab.lib.units import inch

# --- Constants & Paths ---
REPORTS_DIR = "vault_storage/reports"
if not os.path.exists(REPORTS_DIR):
    os.makedirs(REPORTS_DIR)

class ReportGenerator:
    def __init__(self):
        self.styles = getSampleStyleSheet()
        self.custom_style = ParagraphStyle(
            'NeuralStyle',
            parent=self.styles['Normal'],
            fontSize=10,
            leading=14,
            textColor=colors.HexColor("#475569")
        )
        self.header_style = ParagraphStyle(
            'HeaderStyle',
            parent=self.styles['Heading1'],
            fontSize=24,
            textColor=colors.HexColor("#3B82F6"), # Neural Blue
            spaceAfter=20
        )

    def generate_pdf(self, scan_data: dict) -> str:
        """
        Generates a professional PDF report from ScanResult data.
       
        """
        filename = f"PRD_REPORT_{scan_data['scan_id']}.pdf"
        file_path = os.path.join(REPORTS_DIR, filename)
        
        doc = SimpleDocTemplate(file_path, pagesize=A4)
        elements = []

        # 1. HEADER SECTION
        elements.append(Paragraph(f"NEURAL AUDIT: {scan_data['target']}", self.header_style))
        elements.append(Paragraph(f"Artifact ID: {scan_data['scan_id']}", self.custom_style))
        elements.append(Paragraph(f"Timestamp: {scan_data['timestamp']}", self.custom_style))
        elements.append(Spacer(1, 0.3 * inch))

        # 2. EXECUTIVE SUMMARY
        elements.append(Paragraph("EXECUTIVE SUMMARY", self.styles['Heading2']))
        elements.append(Paragraph(scan_data.get('ai_summary', 'No summary available.'), self.custom_style))
        elements.append(Spacer(1, 0.3 * inch))

        # 3. GRC POSTURE INDEX
        score = scan_data.get('grc_posture_index', 0.0)
        score_color = "#10B981" if score >= 8 else "#F59E0B" if score >= 5 else "#EF4444"
        
        elements.append(Paragraph(f"GRC POSTURE INDEX: <font color='{score_color}'>{score}/10</font>", self.styles['Heading3']))
        elements.append(Spacer(1, 0.2 * inch))

        # 4. FINDINGS TABLE
        elements.append(Paragraph("TECHNICAL MANIFESTS", self.styles['Heading2']))
        
        data = [["ID", "VULNERABILITY", "SEVERITY", "SCORE"]]
        for f in scan_data.get('findings', []):
            data.append([
                f.get('id', 'N/A'),
                f.get('title', 'Unknown'),
                f.get('severity', 'Info'),
                str(f.get('score', 0.0))
            ])

        t = Table(data, colWidths=[1*inch, 2.5*inch, 1*inch, 1*inch])
        t.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor("#151921")),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
            ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
            ('BACKGROUND', (0, 1), (-1, -1), colors.HexColor("#F8FAFC")),
            ('GRID', (0, 0), (-1, -1), 0.5, colors.grey)
        ]))
        elements.append(t)
        
        # 5. NEURAL INTERPRETATIONS
        elements.append(Spacer(1, 0.5 * inch))
        elements.append(Paragraph("AI REMEDIATION STRATEGY", self.styles['Heading2']))
        for f in scan_data.get('findings', []):
            elements.append(Paragraph(f"<b>{f['title']}:</b>", self.custom_style))
            elements.append(Paragraph(f.get('ai_explanation', 'No AI analysis found.'), self.custom_style))
            elements.append(Spacer(1, 0.1 * inch))

        doc.build(elements)
        return file_path

report_engine = ReportGenerator()