import os
import json
import logging
import PyPDF2
from groq import Groq
from typing import List, Optional, Dict, Any
from datetime import datetime

# --- Configuration & Constants ---
UPLOAD_DIR = "vault_storage/policies"
MODEL_FAST = "llama-3.1-8b-instant"     # Low Latency (Logs/Fixes)
MODEL_SMART = "llama-3.3-70b-versatile" # High Reasoning (GRC/Forge)

# Setup Professional Logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger("NeuralEngine")

class AIService:
    """
    Centralized AI Service for Pradyuman ShaaS Platform.
    Handles vulnerability interpretation, remediation, and GRC policy audits.
    """

    def __init__(self):
        # FIX: Check for key without crashing on module load
        self.api_key = os.environ.get("GROQ_API_KEY")
        if not self.api_key:
            logger.error("CRITICAL: GROQ_API_KEY missing. Neural Engine is OFFLINE.")
            self.client = None
        else:
            self.client = Groq(api_key=self.api_key)
            logger.info("Neural Engine initialized successfully.")

    async def _call_groq(self, model: str, prompt: str, json_mode: bool = False) -> str:
        """Standardized Groq API handler with safety checks (Async)."""
        if not self.client:
            return "Neural Link Failure: Intelligence engine is offline (Check API Key)."
        
        try:
            response_format = {"type": "json_object"} if json_mode else None
            
            # Using synchronous client inside async method is fine for this implementation,
            # but we must return the result as a string.
            completion = self.client.chat.completions.create(
                model=model,
                messages=[{"role": "user", "content": prompt}],
                temperature=0.3 if json_mode else 0.5,
                response_format=response_format
            )
            return str(completion.choices[0].message.content)
        except Exception as e:
            logger.error(f"Groq API Error ({model}): {str(e)}")
            return f"Neural Link Failure: {str(e)}"

    async def explain_vulnerability(self, finding: Dict[str, Any]) -> str:
        """Explains vulnerabilities for managers using 8B model."""
        prompt = f"""
        Explain this vulnerability for a non-technical manager in 2 sentences:
        Vulnerability: {finding.get('title')}
        Severity: {finding.get('severity')}
        Traceback: {finding.get('description')}
        
        Focus on the business risk and why immediate patching is required.
        """
        # CRITICAL FIX: Added 'await' to return string, not coroutine
        return await self._call_groq(MODEL_FAST, prompt)

    async def generate_scan_summary(self, target: str, findings: List[Dict[str, Any]]) -> str:
        """Executive summary via 70B model for the ScanResult."""
        titles = [f.get('title') for f in findings]
        prompt = f"""
        Analyze the security perimeter of {target}.
        Detected Vulnerabilities: {', '.join(titles) if titles else 'None (Clean Scan)'}
        
        Provide a professional 3-sentence high-level executive summary about the security posture.
        """
        # CRITICAL FIX: Added 'await' to satisfy Pydantic string validation
        return await self._call_groq(MODEL_SMART, prompt)

    async def get_fix_suggestion(self, finding: Dict[str, Any]) -> str:
        """3-step remediation code snippets via 8B model."""
        prompt = f"""
        Provide a concise 3-step remediation for: {finding.get('title')}.
        Technical Detail: {finding.get('description')}
        
        Format:
        1. Identification
        2. Neutralization (with code example)
        3. Verification
        """
        # CRITICAL FIX: Added 'await'
        return await self._call_groq(MODEL_FAST, prompt)

    async def forge_policy(self, context: str, framework: str) -> str:
        """Synthesizes new artifacts for the Policy Forge UI."""
        prompt = f"""
        Generate a professional, enterprise-grade security policy for: "{context}". 
        Must adhere to {framework} standards. 
        Format in professional legal-style markdown with clear section headers.
        """
        # CRITICAL FIX: Added 'await'
        return await self._call_groq(MODEL_SMART, prompt)

    async def compare_policy_with_standard(self, file_path: str, standard: str = "ISO 27001") -> Dict[str, Any]:
        """GRC Gap Analysis using 70B model."""
        raw_text = self.extract_text_from_pdf(file_path)
        if not raw_text.strip():
            return {"error": "Could not extract intelligence from the document."}

        prompt = f"""
        Act as a GRC Auditor. Compare the following policy text against {standard} requirements.
        Policy Data: {raw_text[:5000]}
        
        Return a JSON object with: compliance_score (0-100), key_gaps (list), neural_recommendations (list), executive_summary.
        """
        # CRITICAL FIX: Added 'await' before parsing JSON
        response = await self._call_groq(MODEL_SMART, prompt, json_mode=True)
        try:
            return json.loads(response)
        except Exception as e:
            logger.error(f"JSON Parse Error in Neural Audit: {str(e)}")
            return {"error": "Failed to parse Neural Audit response."}

    @staticmethod
    def extract_text_from_pdf(file_path: str) -> str:
        """Extracts text from local vault storage."""
        text = ""
        try:
            if not os.path.exists(file_path):
                raise FileNotFoundError(f"Artifact not found at {file_path}")
                
            with open(file_path, "rb") as f:
                reader = PyPDF2.PdfReader(f)
                for page in reader.pages:
                    content = page.extract_text()
                    if content:
                        text += content + "\n"
            return text
        except Exception as e:
            logger.error(f"PDF Extraction Error: {str(e)}")
            return ""

# --- Utility Functions ---

def save_policy_pdf(file_bytes: bytes, filename: str) -> str:
    """Stores binary artifacts in backend vault."""
    try:
        if not os.path.exists(UPLOAD_DIR):
            os.makedirs(UPLOAD_DIR)
        file_path = os.path.join(UPLOAD_DIR, filename)
        with open(file_path, "wb") as f:
            f.write(file_bytes)
        logger.info(f"Artifact Sealed: {file_path}")
        return file_path
    except Exception as e:
        logger.error(f"Vault Write Failure: {str(e)}")
        raise IOError("Could not write file to secure storage.")

# Initialize singleton for app-wide use
ai_engine = AIService()