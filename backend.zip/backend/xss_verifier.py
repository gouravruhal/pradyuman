import asyncio
from playwright.async_api import async_playwright


PAYLOAD = "<script>window.__xss='pradyuman'</script>"


async def verify_xss(url: str):

    async with async_playwright() as p:

        browser = await p.chromium.launch(headless=True)
        context = await browser.new_context(ignore_https_errors=True)
        page = await context.new_page()

        try:
            # inject payload through fragment (safe universal injection point)
            test_url = url + "#"+PAYLOAD

            await page.goto(test_url, timeout=15000)

            result = await page.evaluate("window.__xss === 'pradyuman'")

            await browser.close()

            return result

        except:
            await browser.close()
            return False
