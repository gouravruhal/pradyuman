import asyncio
import uuid
import firebase_admin
import json
import os
from datetime import datetime
from urllib.parse import urlparse
from typing import List, Optional

from fastapi import FastAPI, HTTPException, Body, Depends, UploadFile, File
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from firebase_admin import credentials, firestore

# --- Core Neural Modules ---
from vulnerability_scan import run_scan
from risk_engine import calculate_risk_score # Ensure this is your latest logic
from zap_client import zap_alive
from core.sys_provider import SecureVault

from ai_service import ai_engine, save_policy_pdf


from fastapi.responses import FileResponse
from report_generator import report_engine


from dotenv import load_dotenv
load_dotenv()

if not firebase_admin._apps:
    cred = credentials.Certificate("firebase_key.json")
    firebase_admin.initialize_app(cred)
db = firestore.client()

# ---------------- FASTAPI ARCHITECTURE ----------------
app = FastAPI(title="PRADYUMAN: Neural Backend v4.5")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"], 
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

vault = SecureVault()

# ---------------- DATA MODELS ----------------
class AuditRequest(BaseModel):
    target: str
    userId: str
    mode: str = "standard"
    workspaceId: Optional[str] = None 

# ---------------- HELPERS ----------------
def normalize_domain(target: str):
    if not target.startswith("http"):
        target = "https://" + target
    parsed = urlparse(target)
    return parsed.hostname

async def get_or_create_asset(domain: str, uid: str, workspace_id: str):
    assets_ref = db.collection("assets")
    # Tenancy check: Domain + Workspace isolation
    query = assets_ref.where("domain", "==", domain).where("workspaceId", "==", workspace_id).limit(1).stream()

    for doc in query:
        return doc.id

    new_asset = {
        "domain": domain,
        "ownerUid": uid,
        "workspaceId": workspace_id,
        "createdAt": datetime.utcnow(),
        "lastScannedAt": None,
        "latestScore": 10.0, # Start with a clean score
        "scanCount": 0
    }
    doc_ref = assets_ref.document()
    doc_ref.set(new_asset)
    return doc_ref.id

# ---------------- CRYPTO BRIDGE ----------------
@app.post("/api/utils/seal")
async def seal_metadata(payload: dict = Body(...)):
    data = payload.get("data")
    if not data: raise HTTPException(400, "Metadata required for sealing.")
    return {"sealed": vault.seal(data)}

@app.post("/api/utils/open")
async def open_metadata(payload: dict = Body(...)):
    sealed_string = payload.get("sealed")
    if not sealed_string: raise HTTPException(400, "Sealed artifact required.")
    return {"data": vault.open(sealed_string)}

# ---------------- CORE AUDIT ENGINE ----------------
@app.post("/api/audit")
async def start_audit(req: AuditRequest):
    scan_id = f"PRD-SCN-{uuid.uuid4().hex[:8].upper()}"
    domain = normalize_domain(req.target)

    if not domain: raise HTTPException(400, "Target uplink failed: Invalid format.")

    asset_id = await get_or_create_asset(domain, req.userId, req.workspaceId or "personal")

    # Initialize Scan Manifest
    db.collection("scans").document(scan_id).set({
        "scanId": scan_id,
        "assetId": asset_id,
        "ownerUid": req.userId,
        "workspaceId": req.workspaceId,
        "target": domain,
        "status": "queued",
        "startedAt": datetime.utcnow(),
        "riskScore": 0
    })

    asyncio.create_task(execute_scan_logic(scan_id, req.target, asset_id))
    return {"scan_id": scan_id, "status": "queued"}

@app.get("/api/audit/{scan_id}")
async def get_scan_status(scan_id: str):
    doc = db.collection("scans").document(scan_id).get()
    if not doc.exists: raise HTTPException(404, "Neural Artifact Not Found")
    return doc.to_dict()

async def execute_scan_logic(scan_id: str, target: str, asset_id: str):
    try:
        db.collection("scans").document(scan_id).update({"status": "running"})
        
        # Neural Scanning via vulnerability_scan
        result = await run_scan(target, scan_id=scan_id) 
        result_dict = result.dict()

        # AES-256 Sealing for high-integrity storage
        sealed_findings = vault.seal(json.dumps({
            "findings": result_dict["findings"],
            "ai_summary": result_dict.get("ai_summary")
        }))

        # Finalize manifest in root 'scans' collection
        db.collection("scans").document(scan_id).update({
            "status": "completed",
            "completedAt": datetime.utcnow(),
            "riskScore": result_dict.get("grc_posture_index", 0),
            "sealed_data": sealed_findings,
            "ai_summary": result_dict.get("ai_summary", "Neural analysis finalized.")
        })

        # Update Asset Telemetry for Dashboard sync
        db.collection("assets").document(asset_id).update({
            "lastScannedAt": datetime.utcnow(),
            "latestScore": result_dict.get("grc_posture_index", 0),
            "scanCount": firestore.Increment(1)
        })

    except Exception as e:
        db.collection("scans").document(scan_id).update({"status": "failed", "summary": str(e)})

# ---------------- POLICY VAULT (FILE SYSTEM STORAGE) ----------------

@app.post("/api/policies/upload")
async def upload_policy(
    workspaceId: str, 
    userId: str, 
    standard: str = "ISO 27001",
    file: UploadFile = File(...)
):
    """
    Saves PDF to local vault_storage and triggers AI GRC Analysis.
    No Firestore storage for binary data.
    """
    if not file.filename.endswith(".pdf"):
        raise HTTPException(400, "Only PDF artifacts are accepted.")

    file_bytes = await file.read()
    filename = f"{workspaceId}_{uuid.uuid4().hex[:6]}_{file.filename}"
    
    # Save to Backend Filesystem
    file_path = save_policy_pdf(file_bytes, filename)

    # Trigger Neural Audit (Llama-3.3-70b)
    analysis = await ai_engine.compare_policy_with_standard(file_path, standard)

    # Save metadata only to Firestore for UI listing
    policy_doc = {
        "userId": userId,
        "workspaceId": workspaceId,
        "filename": file.filename,
        "localPath": file_path,
        "standard": standard,
        "analysis": analysis,
        "createdAt": datetime.utcnow()
    }
    db.collection("policies").document().set(policy_doc)

    return {"status": "Analysis Complete", "analysis": analysis}

# ---------------- NEURAL AI SERVICE ----------------

@app.post("/api/ai/remediate")
async def get_ai_remediation(payload: dict = Body(...)):
    """Triggers Llama-3.1-8b for log-specific fix suggestions."""
    finding = payload.get("finding", {})
    if not finding: raise HTTPException(400, "Finding context missing.")
    
    # Fetch real-time suggestion from ai_service
    suggestion = await ai_engine.get_fix_suggestion(finding)
    return {"suggestion": suggestion}

# ---------------- DASHBOARD & ASSET APIs ----------------

@app.get("/api/assets/{uid}")
async def get_assets(uid: str):
    """Returns [] instead of 404 to stabilize Frontend Dashboard."""
    assets_ref = db.collection("assets").where("ownerUid", "==", uid).stream()
    return [{**doc.to_dict(), "assetId": doc.id} for doc in assets_ref]

@app.get("/api/assets/{asset_id}/scans")
async def get_asset_scans(asset_id: str):
    scans = db.collection("scans").where("assetId", "==", asset_id).order_by("startedAt", direction=firestore.Query.DESCENDING).stream()
    return [{**d.to_dict(), "id": d.id} for d in scans]

@app.get("/api/scan/{scan_id}/findings")
async def get_scan_findings(scan_id: str):
    doc = db.collection("scans").document(scan_id).get()
    if not doc.exists: raise HTTPException(404, "Artifact Not Found")
    return doc.to_dict()

@app.get("/api/health")
async def health():
    return {"status": "operational", "engine": "Pradyuman Neural v4.5"}


# main.py mein add karein
@app.post("/api/ai/forge-policy")
async def forge_policy(payload: dict = Body(...)):
    """
    Generates a new policy artifact based on company context.
    Uses MODEL_SMART (70B) for professional drafting.
    """
    context = payload.get("context")
    framework = payload.get("framework")
    
    # Neural Synthesis
    prompt = f"Generate a professional {framework} security policy for: {context}. Use legal-style markdown."
    policy_text = await ai_engine._call_groq("llama-3.3-70b-versatile", prompt)
    
    return {"policy": policy_text}


@app.get("/api/reports/download/{scan_id}")
async def download_report(scan_id: str):
    """
    Fetches the sealed artifact, decrypts it, generates a PDF, and serves it.
   
    """
    # 1. Fetch from Firestore
    doc_ref = db.collection("scans").document(scan_id).get()
    if not doc_ref.exists:
        raise HTTPException(404, "Artifact Not Found")
    
    scan_manifest = doc_ref.to_dict()
    
    # 2. Decrypt the sealed data for the PDF generator
    if "sealed_data" not in scan_manifest:
        raise HTTPException(400, "Scan data is corrupted or not sealed.")
        
    decrypted_data = vault.open(scan_manifest["sealed_data"])
    full_data = json.loads(decrypted_data)
    
    # Merge basic info with decrypted findings
    full_data.update({
        "target": scan_manifest["target"],
        "scan_id": scan_id,
        "timestamp": scan_manifest["startedAt"].isoformat(),
        "grc_posture_index": scan_manifest["riskScore"],
        "ai_summary": scan_manifest["ai_summary"]
    })

    # 3. Generate PDF
    file_path = report_engine.generate_pdf(full_data)
    
    # 4. Serve file from local backend storage
    return FileResponse(
        path=file_path, 
        filename=f"Pradyuman_Report_{scan_id}.pdf",
        media_type='application/pdf'
    )

@app.post("/api/ai/forge-policy")
async def api_forge_policy(payload: dict = Body(...)):
    return {"policy": await ai_engine.forge_policy(payload['context'], payload['framework'])}



@app.post("/api/ai/forge-policy")
async def api_forge_policy(payload: dict = Body(...)):
    """
    Triggers Neural Synthesis for GRC artifacts.
   
    """
    context = payload.get('context')
    framework = payload.get('framework')
    
    if not context or not framework:
        raise HTTPException(400, "Context and Framework are mandatory for synthesis.")
    
    # Verified Call: Now properly awaiting an async method
    policy_text = await ai_engine.forge_policy(context, framework)
    
    return {"policy": policy_text}




if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)  