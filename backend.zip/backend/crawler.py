import httpx
from bs4 import BeautifulSoup
from urllib.parse import urljoin, urlparse
from zap_client import zap_client


MAX_DEPTH = 2
MAX_PAGES = 40


async def crawl(start_url):

    visited = set()
    to_visit = [(start_url, 0)]
    discovered = set()

    domain = urlparse(start_url).netloc

    # all traffic now forced through ZAP
    async with zap_client() as client:

        while to_visit and len(visited) < MAX_PAGES:

            url, depth = to_visit.pop(0)

            if url in visited or depth > MAX_DEPTH:
                continue

            visited.add(url)

            try:
                r = await client.get(url)
                soup = BeautifulSoup(r.text, "html.parser")

                links = soup.find_all("a", href=True)

                for link in links:
                    href = link["href"]
                    absolute = urljoin(url, href)

                    parsed = urlparse(absolute)

                    if parsed.netloc == domain:
                        clean = parsed.scheme + "://" + parsed.netloc + parsed.path

                        if clean not in visited:
                            discovered.add(clean)
                            to_visit.append((clean, depth + 1))

            except:
                pass

    return list(discovered)
