import httpx
import asyncio

ZAP_URL = "http://127.0.0.1:8090"


# ---------------------------
# Proxy enforced client (NEW httpx compatible)
# ---------------------------
def zap_client():

    transport = httpx.AsyncHTTPTransport(
        proxy="http://127.0.0.1:8090",
        retries=2
    )

    return httpx.AsyncClient(
        transport=transport,
        verify="zap_root_ca.pem",
        timeout=20,
        trust_env=False
    )


# ---------------------------
# Check zap availability
# ---------------------------
async def zap_alive():
    async with httpx.AsyncClient(timeout=5) as client:
        r = await client.get(f"{ZAP_URL}/JSON/core/view/version/")
        return r.status_code == 200


# ---------------------------
# Wait for passive scan
# ---------------------------
async def wait_for_passive_scan():
    async with httpx.AsyncClient(timeout=10) as client:
        while True:
            r = await client.get(f"{ZAP_URL}/JSON/pscan/view/recordsToScan/")
            remaining = int(r.json().get("recordsToScan", 0))
            if remaining == 0:
                break
            await asyncio.sleep(1)


# ---------------------------
# Get site tree
# ---------------------------
async def get_site_tree(base_url):
    async with httpx.AsyncClient(timeout=10) as client:
        r = await client.get(f"{ZAP_URL}/JSON/core/view/urls/?baseurl={base_url}")
        return r.json().get("urls", [])


# ---------------------------
# Get passive alerts
# ---------------------------
async def get_passive_alerts(base_url):
    async with httpx.AsyncClient(timeout=20) as client:

        start = 0
        all_alerts = []

        while True:
            r = await client.get(
                f"{ZAP_URL}/JSON/alert/view/alerts/?start={start}&count=500"
            )

            data = r.json().get("alerts", [])
            if not data:
                break

            # keep only alerts belonging to target
            for a in data:
                if base_url in a.get("url", ""):
                    all_alerts.append(a)

            start += 500

        return all_alerts

# start active scan
async def start_active_scan(url):
    async with httpx.AsyncClient(timeout=20) as client:
        r = await client.get(
            f"{ZAP_URL}/JSON/ascan/action/scan/?url={url}&recurse=true&inScopeOnly=false"
        )
        return r.json().get("scan")


# get active scan status
async def active_scan_status(scan_id):
    async with httpx.AsyncClient(timeout=10) as client:
        r = await client.get(
            f"{ZAP_URL}/JSON/ascan/view/status/?scanId={scan_id}"
        )
        return int(r.json().get("status", 0))


# wait until active scan finishes
async def wait_active_scan(scan_id):
    import asyncio
    while True:
        status = await active_scan_status(scan_id)
        if status >= 100:
            break
        await asyncio.sleep(2)


async def wait_for_alerts(base_url, minimum=1, timeout=60):
    import time
    start = time.time()

    while time.time() - start < timeout:
        alerts = await get_passive_alerts(base_url)
        if len(alerts) >= minimum:
            return alerts
        await asyncio.sleep(2)

    return []
