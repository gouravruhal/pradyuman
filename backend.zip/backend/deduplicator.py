import hashlib
from urllib.parse import urlparse, parse_qs

# Normalize URL so same endpoint isn't counted multiple times
def normalize_url(url: str):
    try:
        parsed = urlparse(url)

        # remove query values but keep parameter names
        params = parse_qs(parsed.query)
        param_keys = sorted(params.keys())

        normalized = f"{parsed.scheme}://{parsed.netloc}{parsed.path}"
        if param_keys:
            normalized += "?" + "&".join(param_keys)

        return normalized.lower()

    except Exception:
        return url


# Create unique fingerprint of vulnerability
def vuln_fingerprint(vuln: dict):
    """
    Generates deterministic hash for vulnerability identity
    """

    location = normalize_url(vuln.get("location", ""))
    title = vuln.get("title", "")
    severity = vuln.get("severity", "")
    param = vuln.get("parameter", "")

    raw = f"{title}|{severity}|{location}|{param}"

    return hashlib.sha256(raw.encode()).hexdigest()


# Remove duplicates
def deduplicate_findings(findings: list):
    unique = {}
    for f in findings:
        fp = vuln_fingerprint(f)

        # keep highest confidence if duplicate appears
        if fp not in unique:
            unique[fp] = f
        else:
            old = unique[fp]
            if (f.get("confidence", 0) or 0) > (old.get("confidence", 0) or 0):
                unique[fp] = f

    return list(unique.values())
