
export type Severity = 'Critical' | 'High' | 'Medium' | 'Low' | 'Info';

export interface Vulnerability {
  id: string;
  title: string;
  severity: Severity;
  owaspMapping: string;
  isoMapping: string;
  nistMapping: string;
  exploitability: number; // 1-10
  impact: number; // 1-10
  status: 'Open' | 'Mitigated' | 'Ignored';
  detectedAt: string;
  description: string;
  remediation: string;
}

export interface ScanJob {
  id: string;
  target: string;
  status: 'Queued' | 'Crawling' | 'Testing' | 'Analyzing' | 'Completed' | 'Failed';
  progress: number;
  startTime: string;
  findingsCount: number;
}

export interface SecurityLog {
  id: string;
  timestamp: string;
  source: string;
  event: string;
  integrityHash: string;
  status: 'Clean' | 'Suspicious' | 'Threat';
}
