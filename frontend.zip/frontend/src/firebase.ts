// src/firebase.ts
import { initializeApp, getApps, getApp } from "firebase/app";
import { getAuth } from "firebase/auth";
import { getFirestore } from "firebase/firestore";
import { getAnalytics, isSupported } from "firebase/analytics";

// Tera configuration jo tune provide kiya hai
const firebaseConfig = {
  apiKey: "AIzaSyC1-Uf9J46lw7BYwUcabczxz01MGmP_Kq0",
  authDomain: "pradyuman-fde0b.firebaseapp.com",
  projectId: "pradyuman-fde0b",
  storageBucket: "pradyuman-fde0b.firebasestorage.app",
  messagingSenderId: "620972819050",
  appId: "1:620972819050:web:c6c615abb378a819e48013",
  measurementId: "G-3PKG7XXPZ1"
};

// Singleton initialization (Vite friendly)
const app = getApps().length === 0 ? initializeApp(firebaseConfig) : getApp();

// Analytics check (Browser support ke liye)
export const analytics = typeof window !== "undefined" ? getAnalytics(app) : null;

// Ye teeno hum components mein use karenge
export const auth = getAuth(app);
export const db = getFirestore(app);
export default app;