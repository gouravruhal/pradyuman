import React, { useState, useEffect } from 'react';
import { HashRouter, Routes, Route, Link, useLocation, Navigate } from 'react-router-dom';
import { AnimatePresence, motion } from 'framer-motion';
import { 
  Shield, LayoutDashboard, Search, History as HistoryIcon,
  ShieldCheck, Activity, User, Menu, Sun, Moon, Loader2,
  Building, LogOut, Terminal
} from 'lucide-react';

// Firebase Engine Imports
import { auth, db } from './src/firebase';
import { onAuthStateChanged, signOut } from 'firebase/auth';
import { doc, getDoc } from 'firebase/firestore';

// Page Components
import LandingPage from './pages/LandingPage';
import Dashboard from './pages/Dashboard';
import AuditScanner from './pages/AuditScanner';
import HistoryPage from './pages/History';
import CompliancePage from './pages/Compliance';
import LoginPage from './pages/LoginPage';
import ProfilePage from './pages/Profile';
import OrganizationControlPlane from './pages/OrganizationControlPlane';
import OperationsHub from './pages/OperationsHub';

// --- Global Menu Config (Monitoring Terminated) ---
const menuItems = [
  { icon: LayoutDashboard, label: 'Dashboard', path: '/dashboard' },
  { icon: Search, label: 'Audit', path: '/audit' },
  { icon: ShieldCheck, label: 'Policy', path: '/compliance' },
  { icon: HistoryIcon, label: 'Vault', path: '/history' },
  { icon: Terminal, label: 'Ops Hub', path: '/ops' },
  { icon: Building, label: 'Workspace', path: '/workspace' },
];

// --- Secure Route Wrapper ---
const ProtectedRoute = ({ children, user, loading }: { children: React.ReactNode, user: any, loading: boolean }) => {
  if (loading) return (
    <div className="h-screen w-full flex flex-col items-center justify-center bg-[#0B0E14]">
      <Loader2 className="w-12 h-12 text-blue-500 animate-spin opacity-20" />
      <p className="mt-4 font-black text-[10px] uppercase tracking-[0.5em] text-blue-500 animate-pulse">Verifying Identity...</p>
    </div>
  );
  if (!user) return <Navigate to="/login" replace />;
  return <>{children}</>;
};

// --- Sidebar Component ---
const Sidebar = ({ isOpen, user }: { isOpen: boolean, user: any }) => {
  const location = useLocation();
  const handleLogout = () => {
    localStorage.clear();
    signOut(auth);
  };

  return (
    <aside className={`fixed top-0 left-0 h-full border-r border-white/5 bg-[#0B0E14] transition-all duration-300 z-[60] ${isOpen ? 'w-72' : 'w-24'} lg:block hidden`}>
      <div className="flex flex-col h-full p-6">
        <div className="flex items-center gap-4 mb-12 px-2">
          <div className="p-2.5 bg-blue-600 rounded-2xl shadow-lg shadow-blue-500/20">
            <Shield className="w-6 h-6 text-white" />
          </div>
          {isOpen && <span className="font-[1000] text-xl text-white italic tracking-tighter uppercase leading-none">PRADYUMAN</span>}
        </div>

        <nav className="flex-1 space-y-2">
          {menuItems.map((item) => (
            <Link key={item.path} to={item.path}
              className={`flex items-center gap-4 px-4 py-3.5 rounded-2xl transition-all group ${
                location.pathname === item.path 
                  ? 'bg-blue-600 text-white shadow-xl shadow-blue-500/20' 
                  : 'text-slate-500 hover:bg-white/5 hover:text-white'
              }`}>
              <item.icon className="w-5 h-5 shrink-0" />
              {isOpen && <span className="font-bold text-sm tracking-tight">{item.label}</span>}
            </Link>
          ))}
        </nav>

        <div className="pt-6 border-t border-white/5 space-y-2">
          <Link to="/profile" className={`flex items-center gap-4 px-4 py-3.5 rounded-2xl transition-all ${location.pathname === '/profile' ? 'bg-blue-600/10 text-blue-500' : 'text-slate-500 hover:bg-white/5'}`}>
            <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-blue-500 to-indigo-600 flex items-center justify-center text-white shadow-md"><User size={16} /></div>
            {isOpen && <span className="font-bold text-sm">Identity Vault</span>}
          </Link>
          <button onClick={handleLogout} className="w-full flex items-center gap-4 px-4 py-3.5 rounded-2xl text-rose-500 hover:bg-rose-500/10 transition-all group">
            <LogOut size={20} className="shrink-0 group-hover:translate-x-1 transition-transform" />
            {isOpen && <span className="font-black text-[10px] uppercase tracking-widest">Terminate</span>}
          </button>
        </div>
      </div>
    </aside>
  );
};

// --- Neural Shell (Gated Layout) ---
const NeuralShell = ({ children, user, workspaceId, loading }: any) => {
  const location = useLocation();
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const [theme, setTheme] = useState(localStorage.getItem('theme') || 'dark');
  
  const isPublicPage = location.pathname === '/' || location.pathname === '/login';

  useEffect(() => {
    document.documentElement.className = theme;
    localStorage.setItem('theme', theme);
  }, [theme]);

  if (isPublicPage) return <main className="w-full min-h-screen">{children}</main>;

  return (
    <div className="min-h-screen bg-[#0B0E14] flex overflow-x-hidden">
      {user && <Sidebar isOpen={isSidebarOpen} user={user} />}
      
      <div className={`flex-1 transition-all duration-300 ${user ? (isSidebarOpen ? 'lg:ml-72' : 'lg:ml-24') : 'ml-0'} w-full flex flex-col`}>
        {user && (
          <header className="h-20 border-b border-white/5 bg-[#0B0E14]/50 backdrop-blur-xl sticky top-0 z-50 flex items-center justify-between px-8">
            <button onClick={() => setIsSidebarOpen(!isSidebarOpen)} className="p-2.5 hover:bg-white/5 rounded-xl transition-all text-white">
              <Menu className="w-6 h-6" />
            </button>
            <div className="flex items-center gap-6">
              <div className="text-right hidden sm:block">
                <p className="text-[9px] font-black text-slate-500 uppercase tracking-widest leading-none mb-1">Infrastructure</p>
                <p className="text-xs font-bold text-emerald-500 flex items-center gap-2 uppercase tracking-tighter italic">
                  <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" /> Encrypted Link
                </p>
              </div>
              <button onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')} className="p-3 bg-white/5 border border-white/5 rounded-xl text-blue-500 hover:scale-105 transition-all">
                {theme === 'dark' ? <Sun size={18} /> : <Moon size={18} />}
              </button>
            </div>
          </header>
        )}

        <main className={`flex-1 ${user ? 'p-6 md:p-10' : ''} max-w-[1600px] mx-auto w-full`}>
          <AnimatePresence mode="wait">
            <motion.div key={location.pathname} initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -15 }} transition={{ duration: 0.3 }}>
              {children}
            </motion.div>
          </AnimatePresence>
        </main>
      </div>
    </div>
  );
};

const App = () => {
  const [user, setUser] = useState<any>(null);
  const [workspaceId, setWorkspaceId] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (currentUser) => {
      if (currentUser) {
        const cachedOrgId = localStorage.getItem("orgId");
        try {
          const userDoc = await getDoc(doc(db, 'users', currentUser.uid));
          if (userDoc.exists()) {
            const userData = userDoc.data();
            const activeId = userData?.organizationId || cachedOrgId;
            setWorkspaceId(activeId);
            if (activeId) localStorage.setItem("orgId", activeId);
          } else {
            setWorkspaceId(cachedOrgId);
          }
          setUser(currentUser);
        } catch (err) {
          console.error("Neural Sync Error:", err);
          setWorkspaceId(cachedOrgId);
          setUser(currentUser);
        }
      } else {
        setUser(null);
        setWorkspaceId(null);
      }
      setLoading(false);
    });
    return () => unsubscribe();
  }, []);

  return (
    <HashRouter>
      <NeuralShell user={user} workspaceId={workspaceId} loading={loading}>
        <Routes>
          <Route path="/" element={<LandingPage />} />
          <Route path="/login" element={<LoginPage />} />
          <Route path="/dashboard" element={<ProtectedRoute user={user} loading={loading}><Dashboard /></ProtectedRoute>} />
          <Route path="/audit" element={<ProtectedRoute user={user} loading={loading}><AuditScanner /></ProtectedRoute>} />
          <Route path="/compliance" element={<ProtectedRoute user={user} loading={loading}><CompliancePage /></ProtectedRoute>} />
          <Route path="/history" element={<ProtectedRoute user={user} loading={loading}><HistoryPage workspaceId={workspaceId!} /></ProtectedRoute>} />
          <Route path="/ops" element={<ProtectedRoute user={user} loading={loading}><OperationsHub workspaceId={workspaceId!} /></ProtectedRoute>} />
          <Route path="/workspace" element={<ProtectedRoute user={user} loading={loading}><OrganizationControlPlane workspaceId={workspaceId!} /></ProtectedRoute>} />
          <Route path="/profile" element={<ProtectedRoute user={user} loading={loading}><ProfilePage /></ProtectedRoute>} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </NeuralShell>
    </HashRouter>
  );
};

export default App;