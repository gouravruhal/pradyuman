export default {
  plugins: {
    '@tailwindcss/postcss': {}, // Updated from 'tailwindcss'
    autoprefixer: {},
  },
}