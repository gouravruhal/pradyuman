import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { db, auth } from '../src/firebase';
import { 
  collection, query, onSnapshot, orderBy, 
  where, updateDoc, doc, serverTimestamp 
} from 'firebase/firestore';
import { 
  ShieldAlert, Activity, Globe, Search, ShieldCheck, 
  Cpu, Lock, Terminal, Fingerprint, ChevronRight,
  Zap, AlertCircle, RefreshCw
} from 'lucide-react';

const API = "http://localhost:8000";

const OperationsHub = ({ workspaceId }: { workspaceId: string }) => {
  const [activeOps, setActiveOps] = useState<any[]>([]);
  const [backlog, setBacklog] = useState<any[]>([]);
  const navigate = useNavigate();
  
  const userRole = localStorage.getItem("role"); // ADMIN or OPERATOR
  const isManagement = userRole === "ADMIN";
  const currentUserUid = auth.currentUser?.uid;

  // ---------------------------------------------------------
  // CRYPTO BRIDGE: Decryption Utility
  // ---------------------------------------------------------
  const decryptMetadata = async (sealedData: string) => {
    try {
      const res = await fetch(`${API}/api/utils/open`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ sealed: sealedData })
      });
      const result = await res.json();
      return result.data; // Returns the plain text URL/Description
    } catch (err) {
      console.error("Decryption Link Error:", err);
      return "RESTRICTED_ACCESS";
    }
  };

  // ---------------------------------------------------------
  // SYNC: MISSION BACKLOG & ACTIVE ENGAGEMENTS
  // ---------------------------------------------------------
  useEffect(() => {
    if (!workspaceId || !currentUserUid) return;

    // 1. Mission Backlog (All Open Tickets in the Org)
    const qBacklog = query(
      collection(db, `organizations/${workspaceId}/tickets`),
      where("status", "==", "OPEN"),
      orderBy("createdAt", "desc")
    );

    const unsubBacklog = onSnapshot(qBacklog, (s) => {
      setBacklog(s.docs.map(d => ({ id: d.id, ...d.data() })));
    });

    // 2. Active Engagements (Only tickets assigned to CURRENT user)
    const qActive = query(
      collection(db, `organizations/${workspaceId}/tickets`),
      where("assignedTo", "==", currentUserUid),
      where("status", "==", "IN_PROGRESS")
    );

    const unsubActive = onSnapshot(qActive, (s) => {
      setActiveOps(s.docs.map(d => ({ id: d.id, ...d.data() })));
    });

    return () => { unsubBacklog(); unsubActive(); };
  }, [workspaceId, currentUserUid]);

  // ---------------------------------------------------------
  // LOGIC: CLAIM MISSION (Operator takes the ticket)
  // ---------------------------------------------------------
  const handleClaim = async (ticketId: string) => {
    try {
      const ticketRef = doc(db, `organizations/${workspaceId}/tickets`, ticketId);
      await updateDoc(ticketRef, {
        status: 'IN_PROGRESS',
        assignedTo: currentUserUid,
        claimedAt: serverTimestamp()
      });
    } catch (err) {
      console.error("Protocol Error: Claim Failed", err);
    }
  };

  return (
    <div className="space-y-12 max-w-[1600px] mx-auto pb-32 px-6 lg:px-10">
      
      {/* HEADER: SOC TELEMETRY */}
      <div className="flex flex-col lg:flex-row justify-between items-start lg:items-end gap-8 border-b border-white/5 pb-12">
        <div className="space-y-4">
          <div className="flex items-center gap-3 text-[10px] font-black uppercase tracking-[0.4em] text-blue-500">
            <Activity className="w-4 h-4 animate-pulse" /> Operations Center v4.2
          </div>
          <h1 className="text-6xl font-[1000] uppercase italic tracking-tighter">
            Mission <span className="text-blue-500">Control</span>
          </h1>
          <p className="text-slate-500 font-medium text-lg italic">
            Cluster_Identity: {workspaceId.slice(0, 10).toUpperCase()} // Status: Secure
          </p>
        </div>

        <div className="flex items-center gap-4 bg-[#151921] p-1.5 rounded-[2rem] border border-white/5 shadow-2xl">
          <div className="px-8 py-3 text-center border-r border-white/5">
             <p className="text-[9px] font-black text-slate-500 uppercase tracking-widest">Active Engagements</p>
             <p className="text-2xl font-[1000] italic text-emerald-500">{activeOps.length}</p>
          </div>
          <div className="px-8 py-3 text-center">
             <p className="text-[9px] font-black text-slate-500 uppercase tracking-widest">Global Backlog</p>
             <p className="text-2xl font-[1000] italic text-blue-500">{backlog.length}</p>
          </div>
        </div>
      </div>

      {/* SOC STAT MATRIX */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        <StatCard label="Network Latency" val="0.04ms" icon={Zap} color="text-blue-500" />
        <StatCard label="Access Level" val={isManagement ? "ADMIN" : "OPERATOR"} icon={Fingerprint} color="text-emerald-500" />
        <StatCard label="Encrypted Link" val="ACTIVE" icon={Lock} color="text-blue-500" />
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-12 gap-10">
        
        {/* PIPELINE 01: MISSION BACKLOG */}
        <div className="xl:col-span-7 space-y-8">
           <div className="flex items-center gap-4">
              <Terminal className="text-blue-500 w-6 h-6" />
              <h3 className="text-2xl font-[1000] uppercase italic tracking-tighter text-white">Mission <span className="text-blue-500">Backlog</span></h3>
           </div>

           <div className="space-y-4">
              {backlog.length === 0 ? (
                <div className="glass-card p-24 rounded-[3.5rem] text-center opacity-20 border-2 border-dashed border-white/5">
                   <Cpu className="w-16 h-16 mx-auto mb-6" />
                   <p className="font-black uppercase tracking-widest text-xs">No Pending Directives</p>
                </div>
              ) : (
                backlog.map(ticket => (
                  <OperationCard 
                    key={ticket.id} 
                    ticket={ticket} 
                    onAction={() => handleClaim(ticket.id)}
                    actionLabel="Claim Mission"
                    isClaimed={false}
                  />
                ))
              )}
           </div>
        </div>

        {/* PIPELINE 02: ACTIVE TERMINAL */}
        <div className="xl:col-span-5 space-y-8">
           <div className="flex items-center gap-4">
              <Activity className="text-emerald-500 w-6 h-6" />
              <h3 className="text-2xl font-[1000] uppercase italic tracking-tighter text-white">Active <span className="text-emerald-500">Terminal</span></h3>
           </div>

           <div className="space-y-4">
              {activeOps.length === 0 ? (
                <div className="glass-card p-24 rounded-[3.5rem] text-center opacity-20 border border-white/5">
                   <AlertCircle className="w-16 h-16 mx-auto mb-6" />
                   <p className="font-black uppercase tracking-widest text-xs italic text-slate-500">Standby Mode: Claim a mission to proceed</p>
                </div>
              ) : (
                activeOps.map(op => (
                  <OperationCard 
                    key={op.id} 
                    ticket={op} 
                    onAction={(decryptedUrl: string) => navigate('/audit', { state: { targetUrl: decryptedUrl } })}
                    actionLabel="Launch Audit"
                    isClaimed={true}
                    decryptFn={decryptMetadata}
                  />
                ))
              )}
           </div>
        </div>

      </div>
    </div>
  );
};

/**
 * SUB-COMPONENT: OperationCard
 * Logical Implementation: Decrypts metadata only when mission is active.
 */
const OperationCard = ({ ticket, onAction, actionLabel, isClaimed, decryptFn }: any) => {
  const [decryptedTarget, setDecryptedTarget] = useState<string | null>(null);
  const [isDecrypting, setIsDecrypting] = useState(false);

  useEffect(() => {
    if (isClaimed && decryptFn && ticket.sealedTarget) {
      setIsDecrypting(true);
      decryptFn(ticket.sealedTarget).then((data: string) => {
        setDecryptedTarget(data);
        setIsDecrypting(false);
      });
    }
  }, [isClaimed, ticket.sealedTarget, decryptFn]);

  return (
    <motion.div 
      initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }}
      className={`glass-card p-10 rounded-[3rem] border border-white/5 group transition-all ${isClaimed ? 'bg-emerald-500/5 border-emerald-500/20' : 'hover:border-blue-500/40'}`}
    >
      <div className="flex justify-between items-start mb-10">
         <div className={`p-4 rounded-2xl ${isClaimed ? 'bg-emerald-500 text-white shadow-xl shadow-emerald-500/20' : 'bg-blue-600/10 text-blue-500'}`}>
            {isClaimed ? <ShieldCheck size={20} /> : <Fingerprint size={20} />}
         </div>
         <div className="text-right">
            <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-1">TRC_{ticket.id.slice(-6).toUpperCase()}</p>
            <p className="text-[10px] font-bold text-slate-600 italic">Dispatched: {new Date(ticket.createdAt?.toDate()).toLocaleTimeString()}</p>
         </div>
      </div>

      <div className="space-y-6 mb-10">
         <h4 className="text-2xl font-[1000] italic tracking-tighter uppercase leading-none text-white">
            {isClaimed ? (isDecrypting ? "Opening Vault..." : decryptedTarget) : "Sealed Recon Metadata"}
         </h4>
         {!isClaimed && (
           <div className="flex items-center gap-3 px-4 py-2 bg-blue-600/5 border border-blue-500/20 rounded-xl w-fit">
              <Lock size={12} className="text-blue-500" /> 
              <span className="text-[9px] font-black text-blue-500 uppercase tracking-widest">AES-256 Crypto Sealed</span>
           </div>
         )}
      </div>

      <button 
        onClick={() => onAction(decryptedTarget)}
        className={`w-full py-5 rounded-2xl font-black text-[10px] uppercase tracking-widest flex items-center justify-center gap-3 transition-all ${isClaimed ? 'bg-emerald-600 text-white hover:bg-emerald-500 shadow-2xl shadow-emerald-600/20' : 'bg-white/[0.03] border border-white/10 text-slate-500 hover:text-blue-500 hover:border-blue-500/50'}`}
      >
        {actionLabel} <ChevronRight size={16} />
      </button>
    </motion.div>
  );
};

const StatCard = ({ label, val, icon: Icon, color }: any) => (
  <div className="glass-card p-12 rounded-[3.5rem] bg-[#151921] border border-white/5 relative overflow-hidden group shadow-2xl">
    <div className="absolute top-0 right-0 p-8 opacity-[0.03] group-hover:opacity-[0.08] transition-opacity">
       <Icon size={120} />
    </div>
    <div className="relative z-10 space-y-6">
      <div className={`p-4 rounded-2xl bg-white/[0.02] w-fit ${color}`}><Icon size={24} /></div>
      <div>
        <p className="text-[11px] font-black text-slate-500 uppercase tracking-[0.4em] mb-2">{label}</p>
        <p className="text-5xl font-[1000] text-white italic tracking-tighter leading-none">{val}</p>
      </div>
    </div>
  </div>
);

export default OperationsHub;