import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ShieldCheck } from 'lucide-react';
import PolicyAuditor from './PolicyAuditor';
import PolicyForge from './PolicyForge';

const CompliancePage = ({ workspaceId, userId }: any) => {
  const [activeTab, setActiveTab] = useState<'auditor' | 'forge'>('auditor');

  return (
    <div className="space-y-12 max-w-[1600px] mx-auto pb-32">
      <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} className="flex flex-col md:flex-row md:items-end justify-between gap-12">
        <div className="space-y-4">
          <div className="flex items-center gap-3 text-[10px] font-black uppercase tracking-[0.4em] text-blue-500">
            <ShieldCheck className="w-4 h-4" /> Compliance Control Plane v4.5
          </div>
          <h1 className="text-6xl font-[1000] text-white tracking-tighter uppercase leading-none italic">
            Neural <span className="text-blue-500">Governance</span>
          </h1>
          <p className="text-slate-500 font-medium italic text-lg max-w-2xl leading-relaxed">
            Autonomous gap analysis and GRC policy synthesis via Pradyuman Neural Core.
          </p>
        </div>

        <div className="flex bg-[#151921] p-1.5 rounded-[2.5rem] border border-white/5 shadow-2xl min-w-[340px]">
          {(['auditor', 'forge'] as const).map(tab => (
            <button key={tab} onClick={() => setActiveTab(tab)}
              className={`flex-1 py-4 rounded-[2rem] text-[10px] font-black uppercase tracking-widest transition-all duration-500 ${activeTab === tab ? 'bg-blue-600 text-white' : 'text-slate-500 hover:text-white'}`}>
              {tab === 'auditor' ? 'Policy Auditor' : 'Policy Forge'}
            </button>
          ))}
        </div>
      </motion.div>

      <AnimatePresence mode="wait">
        {activeTab === 'auditor' ? (
          <motion.div key="auditor" initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: 20 }}>
            <PolicyAuditor workspaceId={workspaceId} userId={userId} />
          </motion.div>
        ) : (
          <motion.div key="forge" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }}>
            <PolicyForge />
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default CompliancePage;