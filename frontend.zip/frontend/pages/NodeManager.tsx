import React, { useState, useMemo } from 'react';
import { motion } from 'framer-motion';
import { UserPlus, Loader2, Trash2, ShieldAlert } from 'lucide-react';
import { db } from '../src/firebase';
import { initializeApp, getApp, getApps } from 'firebase/app';
import { getAuth, createUserWithEmailAndPassword, signOut } from 'firebase/auth';
import { doc, setDoc, serverTimestamp } from 'firebase/firestore';

const API = "http://localhost:8000";

// --- ACTION REQUIRED: Copy these EXACTLY from your Firebase Project Settings ---
const firebaseConfig = {
  apiKey: "AIzaSyC1-Uf9J46lw7BYwUcabczxz01MGmP_Kq0", // <-- VERIFY THIS KEY
  authDomain: "pradyuman-fde0b.firebaseapp.com",
  projectId: "pradyuman-fde0b",
  storageBucket: "pradyuman-fde0b.firebasestorage.app",
  messagingSenderId: "620972819050",
  appId: "1:620972819050:web:c6c615abb378a819e48013"
};

const NodeManager = ({ workspaceId, isManagement, members, orgData }: any) => {
  const [targetEmail, setTargetEmail] = useState('');
  const [targetPassword, setTargetPassword] = useState('');
  const [targetRole, setTargetRole] = useState<'ADMIN' | 'OPERATOR'>('OPERATOR');
  const [isUpdating, setIsUpdating] = useState(false);

  const saturation = useMemo(() => {
    return Math.round((members.length / (orgData?.seatPolicy?.maxSeats || 1)) * 100);
  }, [members, orgData]);

  const handleProvision = async () => {
    if (!isManagement) return;
    if (members.length >= (orgData?.seatPolicy?.maxSeats || 0)) {
      return alert("CRITICAL: Enclave Seat Limit Reached.");
    }

    setIsUpdating(true);
    
    // Safety check for secondary app initialization to avoid "already exists" error
    const secondaryApp = getApps().find(app => app.name === 'SecondaryAuth') 
      ? getApp('SecondaryAuth')
      : initializeApp(firebaseConfig, 'SecondaryAuth');
    
    const secondaryAuth = getAuth(secondaryApp);

    try {
      // 1. Create Auth Entry
      const cred = await createUserWithEmailAndPassword(secondaryAuth, targetEmail, targetPassword);
      const newUid = cred.user.uid;

      // 2. Seal Metadata
      const res = await fetch(`${API}/api/utils/seal`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ data: targetEmail })
      });
      const { sealed } = await res.json();

      // 3. Parallel DB Write: Global Profile & Org Registry
      await Promise.all([
        setDoc(doc(db, 'users', newUid), {
          uid: newUid,
          sealedEmail: sealed,
          organizationId: workspaceId,
          role: targetRole,
          createdAt: serverTimestamp()
        }),
        setDoc(doc(db, `organizations/${workspaceId}/members`, newUid), {
          uid: newUid,
          email: targetEmail,
          role: targetRole,
          joinedAt: serverTimestamp()
        })
      ]);

      await signOut(secondaryAuth);
      setTargetEmail(''); setTargetPassword('');
      alert(`Neural Node Successfully Linked: ${targetRole}`);
    } catch (err: any) {
      console.error("Provisioning Protocol Failure:", err);
      alert(`Access Denied: ${err.message}`);
    } finally {
      setIsUpdating(false);
    }
  };

  return (
    <div className="grid grid-cols-1 xl:grid-cols-12 gap-10">
      {/* SEAT TELEMETRY */}
      <div className="xl:col-span-8 glass-card p-12 rounded-[3.5rem] relative overflow-hidden border border-white/5 shadow-2xl">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
          <div className="space-y-8">
            <h4 className="text-[10px] font-black text-slate-500 uppercase tracking-[0.4em]">Node Governance</h4>
            <div className="space-y-4">
              <div className="flex justify-between text-sm font-black uppercase italic tracking-tighter text-white">
                <span>Enclave Saturation</span>
                <span className="text-blue-500">{saturation}%</span>
              </div>
              <div className="h-3 w-full bg-[#0B0E14] rounded-full overflow-hidden border border-white/5">
                <motion.div initial={{ width: 0 }} animate={{ width: `${saturation}%` }} className="h-full bg-blue-600 shadow-[0_0_15px_rgba(37,99,235,0.3)]" />
              </div>
            </div>
            <p className="text-xs font-bold text-slate-500 italic uppercase">Active Nodes: {members.length} / {orgData?.seatPolicy?.maxSeats}</p>
          </div>
          <div className="flex justify-center">
             <div className="relative w-40 h-40">
                <svg className="w-full h-full -rotate-90">
                   <circle cx="50%" cy="50%" r="45%" stroke="#ffffff05" strokeWidth="8" fill="transparent" />
                   <motion.circle cx="50%" cy="50%" r="45%" stroke="#2563eb" strokeWidth="8" fill="transparent" strokeLinecap="round" strokeDasharray="283" initial={{ strokeDashoffset: 283 }} animate={{ strokeDashoffset: 283 - (283 * saturation / 100) }} />
                </svg>
                <div className="absolute inset-0 flex flex-col items-center justify-center text-white">
                   <span className="text-4xl font-[1000] italic">{members.length}</span>
                   <span className="text-[8px] font-black text-slate-500 uppercase tracking-widest mt-1">Deployed</span>
                </div>
             </div>
          </div>
        </div>
      </div>

      {/* PROVISIONING INTERFACE */}
      <div className="xl:col-span-4 glass-card p-10 rounded-[3rem] border border-blue-500/10 shadow-2xl bg-[#151921]">
        <h4 className="text-[10px] font-black text-blue-500 uppercase tracking-[0.4em] mb-8 flex items-center gap-2">
          <UserPlus size={14} /> Provision Node
        </h4>
        {isManagement ? (
          <div className="space-y-4">
            <input value={targetEmail} onChange={e => setTargetEmail(e.target.value)} placeholder="Email ID" className="w-full bg-[#0B0E14] border border-white/5 p-5 rounded-2xl text-xs text-white outline-none focus:border-blue-500 transition-all font-bold" />
            <input type="password" value={targetPassword} onChange={e => setTargetPassword(e.target.value)} placeholder="Access Key" className="w-full bg-[#0B0E14] border border-white/5 p-5 rounded-2xl text-xs text-white outline-none focus:border-blue-500 transition-all font-bold" />
            <div className="flex gap-2">
              <button onClick={() => setTargetRole('OPERATOR')} className={`flex-1 py-4 rounded-xl text-[9px] font-black uppercase tracking-widest transition-all ${targetRole === 'OPERATOR' ? 'bg-blue-600 text-white shadow-lg' : 'bg-[#0B0E14] text-slate-500 border border-white/5'}`}>Operator</button>
              <button onClick={() => setTargetRole('ADMIN')} className={`flex-1 py-4 rounded-xl text-[9px] font-black uppercase tracking-widest transition-all ${targetRole === 'ADMIN' ? 'bg-amber-600 text-white shadow-lg' : 'bg-[#0B0E14] text-slate-500 border border-white/5'}`}>Admin</button>
            </div>
            <button onClick={handleProvision} disabled={isUpdating} className="w-full py-5 bg-white text-black rounded-2xl font-black text-[10px] uppercase tracking-[0.2em] mt-4 hover:bg-blue-500 hover:text-white transition-all active:scale-95 shadow-xl">
              {isUpdating ? <Loader2 className="animate-spin mx-auto" size={18} /> : 'Register Node Artifact'}
            </button>
          </div>
        ) : <div className="text-center py-10 opacity-20"><ShieldAlert size={48} className="mx-auto" /></div>}
      </div>
    </div>
  );
};

export default NodeManager;