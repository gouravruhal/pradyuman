import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useLocation } from 'react-router-dom';
import { 
  Zap, RefreshCw, Cpu, ShieldAlert, CheckCircle2, 
  Lock, Globe, Search, AlertCircle, Terminal, 
  ShieldCheck, BarChart3, Activity, Sparkles, Wand2
} from 'lucide-react';
import { auth } from '../src/firebase';
import IntelligenceReport from './IntelligenceReport';

const API = "http://localhost:8000";

const AuditScanner = () => {
  const location = useLocation();
  const [target, setTarget] = useState('');
  const [isScanning, setIsScanning] = useState(false);
  const [scanStep, setScanStep] = useState(0);
  const [report, setReport] = useState<any>(null);
  const [aiInsight, setAiInsight] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [scanId, setScanId] = useState<string | null>(null);

  // --- 1. TICKET INTEGRATION ---
  useEffect(() => {
    if (location.state && (location.state as any).targetUrl) {
      setTarget((location.state as any).targetUrl);
    }
  }, [location]);

  const steps = [
    { label: 'Surface Mapping', info: 'Crawling subdomains & endpoints.', icon: Globe },
    { label: 'Vulnerability Probe', info: 'Executing SQLi, XSS & SSTI modules.', icon: ShieldAlert },
    { label: 'Integrity Analysis', info: 'Verifying TLS & GRC compliance.', icon: ShieldCheck },
    { label: 'Sealing Report', info: 'AES-256 encryption & vault storage.', icon: Lock }
  ];

  // --- 2. CRYPTO DECRYPTION BRIDGE ---
  const decryptSealedData = async (sealedData: string) => {
    try {
      const res = await fetch(`${API}/api/utils/open`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ sealed: sealedData })
      });
      const result = await res.json();
      return JSON.parse(result.data);
    } catch (err) {
      console.error("Neural Decryption Link Severed:", err);
      return null;
    }
  };

  const validateTarget = (input: string) => {
    try {
      const url = new URL(input.startsWith('http') ? input : `https://${input}`);
      return url.hostname.includes('.');
    } catch {
      return false;
    }
  };

  // --- 3. MAIN SCAN ORCHESTRATION ---
  const handleStartScan = async () => {
    setError(null);
    if (!target) return setError('Target ID required for neural uplink.');
    if (!validateTarget(target)) return setError('Invalid Target format detected.');

    setReport(null);
    setIsScanning(true);
    setScanStep(0);

    try {
      const startRes = await fetch(`${API}/api/audit`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          target,
          userId: auth.currentUser?.uid || 'guest',
          workspaceId: "personal" // Defaulting to personal workspace
        })
      });

      if (!startRes.ok) throw new Error('Infrastructure rejected the uplink request.');
      const { scan_id } = await startRes.json();
      setScanId(scan_id);

      // --- 4. POLLING LOGIC (Synced with Status Codes) ---
      let status = "queued";
      while (status !== "completed") {
        await new Promise(r => setTimeout(r, 2500));
        const poll = await fetch(`${API}/api/audit/${scan_id}`);
        const data = await poll.json();
        status = data.status;

        if (status === "running") setScanStep(1);
        if (status === "analyzing") setScanStep(2);
        if (status === "completed") setScanStep(3);
        
        if (status === "failed") throw new Error(data.summary || "Neural link severed.");
      }

      setScanStep(4);

      // --- 5. DATA EXTRACTION & DECRYPTION ---
      const findingsRes = await fetch(`${API}/api/scan/${scan_id}/findings`);
      const rawData = await findingsRes.json();

      let finalFindings = rawData.findings || [];
      
      // If data is sealed (AES-256), open the vault
      if (rawData.sealed_data) {
        const openedReport = await decryptSealedData(rawData.sealed_data);
        if (openedReport && openedReport.findings) {
          finalFindings = openedReport.findings;
        }
      }

      setReport(finalFindings);
      setAiInsight(rawData.ai_summary || "Audit protocols finalized. Manifest generated.");

    } catch (err: any) {
      setError(err.message);
    } finally {
      setIsScanning(false);
    }
  };

  return (
    <div className="space-y-12 max-w-[1400px] mx-auto pb-24 px-6 lg:px-10 selection:bg-blue-500/30">
      
      {/* 1. Header Section */}
      <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} className="flex flex-col md:flex-row justify-between items-start md:items-end gap-8">
        <div className="space-y-4">
          <div className="flex items-center gap-3 text-[10px] font-black uppercase tracking-[0.4em] text-blue-500">
            <Activity className="w-4 h-4 animate-pulse" /> PRADYUMAN Neural Core v4.5
          </div>
          <h1 className="text-6xl font-[1000] text-white tracking-tighter uppercase italic leading-none">
            Vulnerability <span className="text-blue-500">Audit</span>
          </h1>
          <p className="text-slate-500 font-medium text-lg max-w-xl italic">
            Target surface mapping and vulnerability probes. Metadata is AES-256 crypto-sealed.
          </p>
        </div>
        
        <div className="flex gap-4 bg-[#151921] p-2 rounded-3xl border border-white/5 shadow-2xl">
          <div className="px-6 py-3 text-center border-r border-white/5">
            <p className="text-[9px] font-black text-slate-500 uppercase tracking-widest">Link Status</p>
            <p className="text-xs font-bold text-emerald-500 flex items-center gap-2 uppercase italic">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" /> Secure
            </p>
          </div>
          <div className="px-6 py-3 text-center">
            <p className="text-[9px] font-black text-slate-500 uppercase tracking-widest">Crypto</p>
            <p className="text-xs font-bold text-blue-500">AES-GCM</p>
          </div>
        </div>
      </motion.div>

      {/* 2. Input Module */}
      <div className="glass-card p-10 rounded-[3.5rem] border border-blue-500/10 relative overflow-hidden shadow-2xl bg-[#151921]/40 backdrop-blur-3xl">
        <div className="absolute top-0 right-0 p-8 opacity-5">
          <Terminal size={140} />
        </div>
        
        <div className="flex flex-col md:flex-row gap-6 relative z-10">
          <div className="flex-1 relative group">
            <Search className="absolute left-6 top-1/2 -translate-y-1/2 text-slate-600 w-5 h-5 group-focus-within:text-blue-500 transition-colors" />
            <input
              type="text"
              value={target}
              onChange={(e) => setTarget(e.target.value)}
              placeholder="https://target-enclave.io"
              className="w-full bg-[#0B0E14] border border-white/5 py-5 pl-16 pr-8 rounded-2xl font-bold text-sm focus:border-blue-500/50 outline-none transition-all shadow-inner text-white selection:bg-blue-500/30"
            />
          </div>
          <button
            onClick={handleStartScan}
            disabled={isScanning}
            className="px-12 py-5 bg-blue-600 text-white rounded-2xl font-black uppercase tracking-widest text-[10px] flex items-center ju

      {/* 4. AI Summary and Heuristic Manifest */}
      {report && (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-12">
          
          <div className="glass-card p-10 rounded-[3.5rem] border-l-8 border-blue-600 bg-[#151921]/60 backdrop-blur-3xl shadow-2xl relative overflow-hidden">
             <div className="absolute top-0 right-0 p-8 opacity-5">
               <Sparkles size={120} />
             </div>
             <div className="flex items-start gap-8 relative z-10">
                <div className="p-4 bg-blue-600 rounded-3xl shadow-xl shadow-blue-500/30 text-white">
                    <Sparkles size={28} className="animate-pulse" />
                </div>
                <div className="space-y-4">
                   <h3 className="text-2xl font-[1000] uppercase italic tracking-tighter text-white leading-none">Neural <span className="text-blue-500">Summary</span></h3>
                   <p className="text-slate-300 font-bold text-sm leading-loose max-w-5xl italic opacity-90 selection:bg-blue-500/50">
                      {aiInsight}
                   </p>
                </div>
             </div>
          </div>

          <div className="pt-16 border-t border-white/5">
            <div className="flex items-center gap-5 mb-14">
              <div className="p-3 bg-blue-500/10 rounded-2xl"><BarChart3 className="text-blue-500 w-8 h-8" /></div>
              <div>
                <h3 className="text-3xl font-[1000] uppercase italic tracking-tighter text-white leading-none">Heuristic <span className="text-blue-500">Manifest</span></h3>
                <p className="text-[10px] font-black text-slate-500 uppercase tracking-[0.4em] mt-2">Target Perimeter: {target}</p>
              </div>
            </div>

            <IntelligenceReport
              target={target}
              findings={report}
              aiSummary={aiInsight}
            />
          </div>
        </motion.div>
      )}

    </div>
  );
};

export default AuditScanner;