import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Code2, Sparkles, Wand2, CheckCircle2, 
  Terminal, ShieldAlert, ChevronRight, Loader2 
} from 'lucide-react';

const API = "http://localhost:8000";

const IntelligenceReport = ({ target, findings, aiSummary }: any) => {
  const [activeFix, setActiveFix] = useState<string | null>(null);
  const [fixLoading, setFixLoading] = useState<string | null>(null);
  const [fixSuggestion, setFixSuggestion] = useState<string | null>(null);

  const getAiRemediation = async (finding: any) => {
    setFixLoading(finding.id);
    setFixSuggestion(null);
    setActiveFix(finding.id);

    try {
      const res = await fetch(`${API}/api/ai/remediate`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ finding })
      });
      const data = await res.json();
      setFixSuggestion(data.suggestion);
    } catch (err) {
      setFixSuggestion("Failed to link with Neural Engine. Try again later.");
    } finally {
      setFixLoading(null);
    }
  };

  return (
    <div className="space-y-8">
      {findings.map((f: any) => (
        <motion.div 
          key={f.id}
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          className="glass-card rounded-[3rem] border border-white/5 bg-[#151921] overflow-hidden group hover:border-blue-500/30 transition-all shadow-2xl"
        >
          <div className="p-10 flex flex-col lg:flex-row gap-10 items-start">
            
            {/* LEFT: LOG CONTENT */}
            <div className="flex-1 space-y-8 w-full">
              <div className="flex justify-between items-center">
                <div className="flex items-center gap-4">
                  <div className={`w-3 h-3 rounded-full animate-pulse ${f.severity === 'Critical' ? 'bg-rose-500 shadow-[0_0_10px_#f43f5e]' : 'bg-amber-500'}`} />
                  <h3 className="text-2xl font-[1000] uppercase italic tracking-tighter text-white">{f.title}</h3>
                </div>
                <span className="bg-white/5 px-4 py-1.5 rounded-full text-[9px] font-black uppercase text-slate-500 tracking-widest border border-white/5">
                  {f.severity} / {f.confidence}
                </span>
              </div>

              {/* TECHNICAL JSON LOG */}
              <div className="space-y-3">
                <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest flex items-center gap-2">
                  <Terminal size={12} /> Technical Traceback (JSON)
                </p>
                <div className="p-6 bg-[#0B0E14] rounded-2xl border border-white/5 overflow-x-auto">
                  <pre className="text-[11px] font-mono text-blue-400/80 leading-relaxed italic">
                    {JSON.stringify({
                      vulnerability_id: f.id,
                      surface: target,
                      risk_score: f.score,
                      remediation_ready: true
                    }, null, 2)}
                  </pre>
                </div>
              </div>

              {/* SIMPLE EXPLANATION */}
              <div className="space-y-3">
                <p className="text-[10px] font-black text-blue-500 uppercase tracking-widest flex items-center gap-2">
                  <Sparkles size={12} /> Neural Interpretation
                </p>
                <p className="text-sm font-bold text-slate-300 italic leading-relaxed pl-2">
                  {f.description}. This means a malicious actor could potentially bypass security controls on your target enclave.
                </p>
              </div>
            </div>

            {/* RIGHT: THE GREEN AI FIX BUTTON */}
            <div className="lg:w-72 w-full flex flex-col gap-4">
              <button 
                onClick={() => getAiRemediation(f)}
                disabled={fixLoading === f.id}
                className="w-full py-6 bg-emerald-600 hover:bg-emerald-500 text-white rounded-3xl font-[1000] uppercase tracking-widest text-[10px] shadow-xl shadow-emerald-900/20 flex items-center justify-center gap-3 transition-all active:scale-95 disabled:opacity-50"
              >
                {fixLoading === f.id ? <Loader2 className="animate-spin" size={18} /> : <Wand2 size={18} />}
                Generate Fix Suggestion
              </button>

              <div className="p-6 bg-white/5 rounded-2xl border border-white/5">
                <p className="text-[9px] font-black text-slate-500 uppercase tracking-[0.3em] mb-2 text-center underline decoration-blue-500/50">Rapid Remediate</p>
                <p className="text-[10px] text-slate-400 text-center italic font-bold">Manual Fix: {f.remediation}</p>
              </div>
            </div>
          </div>

          {/* DYNAMIC AI SUGGESTION PANEL */}
          <AnimatePresence>
            {activeFix === f.id && (
              <motion.div 
                initial={{ height: 0 }}
                animate={{ height: 'auto' }}
                exit={{ height: 0 }}
                className="bg-[#0B0E14] border-t border-emerald-500/20 overflow-hidden"
              >
                <div className="p-10 space-y-6">
                  <div className="flex items-center gap-4 text-emerald-500">
                    <CheckCircle2 size={20} />
                    <h4 className="text-sm font-black uppercase tracking-widest italic">Neural Recommendation</h4>
                  </div>
                  <div className="p-8 bg-emerald-500/5 border border-emerald-500/20 rounded-3xl">
                    <p className="text-sm text-slate-200 font-bold leading-loose italic">
                      {fixSuggestion || "Processing vulnerability vectors... Thinking via Llama-70B."}
                    </p>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </motion.div>
      ))}
    </div>
  );
};

export default IntelligenceReport;