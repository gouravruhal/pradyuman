import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  FileText, Download, ShieldCheck, Lock, Printer, 
  History, Wrench, BrainCircuit, ChevronDown, 
  ChevronUp, Terminal, AlertTriangle, X, 
  CheckCircle2, Info, Activity , ChevronRight
} from 'lucide-react';

const Reports = () => {
  const [expandedLog, setExpandedLog] = useState<string | null>(null);
  const [selectedFix, setSelectedFix] = useState<any | null>(null);
  const [isDecrypting, setIsDecrypting] = useState(false);
  const [vaultOpen, setVaultOpen] = useState(false);

  // Mock Generic Logs Data
  const securityLogs = [
    {
      id: "VULN-001",
      title: "SQL Injection (Blind)",
      severity: "CRITICAL",
      impact: "High",
      genericExplanation: "SQL Injection occurs when an attacker can interfere with the queries that an application makes to its database. In a 'Blind' scenario, the data isn't returned directly, but the server's response time or HTTP status changes based on the query results.",
      genericExample: "Example: Entering 'OR 1=1' into a login field to bypass authentication logic on a generic database table.",
      fixSteps: [
        "Use Parameterized Queries (Prepared Statements) for all database interactions.",
        "Implement a strict Allow-list for all user-supplied input.",
        "Ensure the database user has 'Least Privilege' permissions (e.g., no DROP or TRUNCATE rights).",
        "Enable Web Application Firewall (WAF) SQLi filtering patterns."
      ]
    },
    {
      id: "VULN-002",
      title: "Cross-Site Scripting (Reflected)",
      severity: "HIGH",
      impact: "Medium-High",
      genericExplanation: "Reflected XSS occurs when an untrusted script is 'reflected' off a web application to the user's browser. This usually happens via URL parameters or form submissions that are displayed back to the user without proper sanitization.",
      genericExample: "Example: A search page that displays 'Results for: <script>alert(1)</script>' without encoding the brackets.",
      fixSteps: [
        "Implement context-aware output encoding (e.g., HTML Entity Encoding).",
        "Configure a strong Content Security Policy (CSP) to block inline script execution.",
        "Use modern frontend frameworks that auto-escape data (like React/Vue).",
        "Validate input length and character sets on the server side."
      ]
    }
  ];

  const handleOpenVault = () => {
    setIsDecrypting(true);
    setTimeout(() => {
      setIsDecrypting(false);
      setVaultOpen(true);
    }, 2000);
  };

  return (
    <div className="max-w-6xl mx-auto space-y-10 pb-24 px-6 selection:bg-blue-500/30">
      
      {/* HEADER SECTION */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 border-b border-white/5 pb-10">
        <div className="space-y-4">
          <div className="flex items-center gap-3 text-[10px] font-black uppercase tracking-[0.4em] text-blue-500">
            <Activity className="w-4 h-4 animate-pulse" /> Compliance Floor v4.2
          </div>
          <h1 className="text-5xl font-[1000] tracking-tighter uppercase italic leading-none">
            Audit <span className="text-blue-500">Manifests</span>
          </h1>
          <p className="text-slate-500 font-medium max-w-lg">
            Access AES-256 sealed reports. All AI remediation and explanations are processed via generic heuristic models.
          </p>
        </div>

        {!vaultOpen ? (
          <button 
            onClick={handleOpenVault}
            disabled={isDecrypting}
            className="bg-blue-600 hover:bg-blue-500 text-white px-10 py-4 rounded-2xl font-black uppercase tracking-widest text-xs shadow-xl shadow-blue-600/20 flex items-center gap-4 transition-all active:scale-95 disabled:opacity-50"
          >
            {isDecrypting ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Lock className="w-4 h-4" />}
            {isDecrypting ? 'Decrypting...' : 'Open Secure Vault'}
          </button>
        ) : (
          <div className="flex gap-3">
             <button className="p-4 bg-white/5 rounded-2xl text-slate-400 hover:text-white transition-all border border-white/5"><Printer size={20}/></button>
             <button className="px-8 py-4 bg-blue-600 text-white rounded-2xl font-black uppercase tracking-widest text-xs flex items-center gap-3 shadow-lg shadow-blue-600/20"><Download size={18}/> Export PDF</button>
          </div>
        )}
      </div>

      <AnimatePresence mode="wait">
        {!vaultOpen ? (
          <motion.div 
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="glass-card p-24 rounded-[3.5rem] border-2 border-dashed border-white/5 flex flex-col items-center justify-center text-center space-y-6 opacity-30"
          >
            <Lock size={64} className="text-slate-700" />
            <p className="font-black uppercase tracking-[0.3em] text-sm">Authentication Artifacts Sealed</p>
          </motion.div>
        ) : (
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-10">
            
            {/* COMPLIANCE SUMMARY GRID */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
               <div className="glass-card p-8 rounded-[2.5rem] border border-white/5">
                  <div className="flex items-center gap-3 mb-4 text-emerald-500">
                    <ShieldCheck size={20} />
                    <span className="text-[10px] font-black uppercase tracking-widest">ISO 27001 Status</span>
                  </div>
                  <div className="text-3xl font-[1000] italic uppercase tracking-tighter">ALIGNED</div>
               </div>
               <div className="glass-card p-8 rounded-[2.5rem] border border-white/5">
                  <div className="flex items-center gap-3 mb-4 text-blue-500">
                    <BrainCircuit size={20} />
                    <span className="text-[10px] font-black uppercase tracking-widest">AI Confidence</span>
                  </div>
                  <div className="text-3xl font-[1000] italic uppercase tracking-tighter">98.4%</div>
               </div>
               <div className="glass-card p-8 rounded-[2.5rem] border border-white/5">
                  <div className="flex items-center gap-3 mb-4 text-rose-500">
                    <AlertTriangle size={20} />
                    <span className="text-[10px] font-black uppercase tracking-widest">Open Findings</span>
                  </div>
                  <div className="text-3xl font-[1000] italic uppercase tracking-tighter">{securityLogs.length} BLOCKS</div>
               </div>
            </div>

            {/* LOGS LEDGER SECTION */}
            <div className="glass-card rounded-[3.5rem] border border-white/5 overflow-hidden shadow-2xl">
               <div className="px-10 py-8 border-b border-white/5 bg-white/[0.02] flex items-center justify-between">
                  <h3 className="text-sm font-[1000] uppercase italic tracking-widest text-blue-500">Heuristic Log Ledger</h3>
                  <div className="px-4 py-1.5 bg-blue-600/10 border border-blue-500/20 rounded-full text-[9px] font-black uppercase tracking-widest text-blue-500">GENERIC_MODE_ACTIVE</div>
               </div>

               <div className="p-10 space-y-6">
                 {securityLogs.map((log) => (
                   <div key={log.id} className="border border-white/5 rounded-[2rem] overflow-hidden bg-[#0B0E14]/50">
                      {/* LOG HEADER */}
                      <div className="p-6 flex items-center justify-between">
                         <div className="flex items-center gap-6">
                            <div className={`w-1.5 h-10 rounded-full ${log.severity === 'CRITICAL' ? 'bg-rose-500 shadow-[0_0_10px_rgba(239,68,68,0.5)]' : 'bg-amber-500'}`} />
                            <div>
                               <p className="text-[9px] font-black text-slate-500 uppercase tracking-widest mb-1">{log.id} // {log.severity}</p>
                               <h4 className="text-xl font-black uppercase italic tracking-tighter">{log.title}</h4>
                            </div>
                         </div>
                         
                         <div className="flex items-center gap-3">
                            <button 
                              onClick={() => setExpandedLog(expandedLog === log.id ? null : log.id)}
                              className="px-5 py-2.5 bg-white/5 hover:bg-white/10 rounded-xl text-[10px] font-black uppercase tracking-widest flex items-center gap-2 transition-all"
                            >
                              {expandedLog === log.id ? <ChevronUp size={14}/> : <ChevronDown size={14}/>} AI Explain
                            </button>
                            <button 
                              onClick={() => setSelectedFix(log)}
                              className="px-5 py-2.5 bg-blue-600 text-white rounded-xl text-[10px] font-black uppercase tracking-widest flex items-center gap-2 hover:bg-blue-500 shadow-lg shadow-blue-600/10 transition-all"
                            >
                              <Wrench size={14} /> View Fix
                            </button>
                         </div>
                      </div>

                      {/* AI EXPLANATION SECTION (Accordian) */}
                      <AnimatePresence>
                        {expandedLog === log.id && (
                          <motion.div 
                            initial={{ height: 0, opacity: 0 }} 
                            animate={{ height: 'auto', opacity: 1 }} 
                            exit={{ height: 0, opacity: 0 }}
                            className="overflow-hidden bg-[#151921]/50 border-t border-white/5"
                          >
                             <div className="p-8 space-y-6">
                                <div className="flex gap-4">
                                   <Info className="text-blue-500 shrink-0" size={20} />
                                   <div className="space-y-2">
                                      <p className="text-[10px] font-black text-blue-500 uppercase tracking-widest">Heuristic Definition</p>
                                      <p className="text-sm text-slate-400 font-medium leading-relaxed">{log.genericExplanation}</p>
                                   </div>
                                </div>
                                <div className="flex gap-4 p-6 bg-[#0B0E14] rounded-2xl border border-white/5 italic">
                                   <Terminal className="text-slate-600 shrink-0" size={18} />
                                   <p className="text-xs text-slate-500 font-bold uppercase tracking-tight leading-relaxed">{log.genericExample}</p>
                                </div>
                             </div>
                          </motion.div>
                        )}
                      </AnimatePresence>
                   </div>
                 ))}
               </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* VIEW FIX MODAL (Generic Remediation) */}
      <AnimatePresence>
        {selectedFix && (
          <motion.div 
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="fixed inset-0 z-[200] bg-[#0B0E14]/90 backdrop-blur-xl flex items-center justify-center p-6"
          >
            <motion.div 
              initial={{ scale: 0.95, y: 20 }} animate={{ scale: 1, y: 0 }}
              className="bg-[#151921] border border-white/10 w-full max-w-2xl rounded-[3rem] p-12 relative overflow-hidden shadow-2xl"
            >
              <div className="absolute top-0 right-0 p-10 opacity-5 pointer-events-none"><BrainCircuit size={150} /></div>
              
              <button onClick={() => setSelectedFix(null)} className="absolute top-8 right-8 p-3 hover:bg-white/5 rounded-2xl transition-all">
                <X size={24} className="text-slate-500" />
              </button>

              <div className="relative z-10 space-y-10">
                <div className="space-y-4">
                   <div className="px-4 py-1.5 bg-blue-600/10 border border-blue-500/20 text-blue-500 text-[9px] font-black uppercase tracking-widest rounded-full w-fit">REMEDIATION_PROTOCOL_v4</div>
                   <h3 className="text-4xl font-[1000] uppercase italic tracking-tighter">Fix: {selectedFix.title}</h3>
                </div>

                <div className="space-y-6">
                   <div className="space-y-4">
                      <h5 className="text-[10px] font-black text-blue-500 uppercase tracking-[0.3em] flex items-center gap-2">
                        <CheckCircle2 size={14} /> Standard Implementation Steps
                      </h5>
                      <div className="space-y-3">
                         {selectedFix.fixSteps.map((step: string, i: number) => (
                           <div key={i} className="flex gap-4 p-5 bg-[#0B0E14] border border-white/5 rounded-2xl">
                              <span className="text-blue-500 font-black italic text-xs">0{i+1}</span>
                              <p className="text-xs font-bold text-slate-400 uppercase tracking-tight leading-relaxed">{step}</p>
                           </div>
                         ))}
                      </div>
                   </div>

                   <button className="w-full py-5 bg-blue-600 text-white rounded-2xl font-black uppercase tracking-widest text-[10px] shadow-xl shadow-blue-600/20 hover:bg-blue-500 transition-all flex items-center justify-center gap-3">
                      Generate Implementation Script <ChevronRight size={16} />
                   </button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

    </div>
  );
};

// Internal icon for the Refresh spin
const RefreshCw = ({ className }: { className?: string }) => (
  <svg className={className} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><path d="M21 12a9 9 0 1 1-9-9c2.52 0 4.93 1 6.74 2.74L21 8"/><path d="M21 3v5h-5"/></svg>
);

export default Reports;