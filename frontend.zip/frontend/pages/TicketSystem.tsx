import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Ticket, Plus, Globe, Loader2, ShieldAlert, 
  Terminal, Lock, Fingerprint, Activity, ChevronRight,
  Clock, CheckCircle2, AlertCircle
} from 'lucide-react';

// Protocol Engines
import { db, auth } from '../src/firebase';
import { collection, addDoc, serverTimestamp, onSnapshot, query, orderBy } from 'firebase/firestore';

const API = "http://localhost:8000";

// --- PROTOCOL TYPES ---
interface TicketData {
  id: string;
  sealedTarget: string;
  rawDescription: string;
  status: 'OPEN' | 'IN_PROGRESS' | 'COMPLETED';
  priority: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
  raisedBy: string;
  createdAt: any;
}

// FIX: Define the props interface clearly
interface TicketCardProps {
  ticket: TicketData;
}

const TicketSystem = ({ workspaceId, isManagement }: { workspaceId: string, isManagement: boolean }) => {
  const [targetUrl, setTargetUrl] = useState('');
  const [desc, setDesc] = useState('');
  const [priority, setPriority] = useState<'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL'>('HIGH');
  
  const [tickets, setTickets] = useState<TicketData[]>([]);
  const [isDispatching, setIsDispatching] = useState(false);
  const [loading, setLoading] = useState(true);

  // SYNC: Neural Backlog Connection
  useEffect(() => {
    if (!workspaceId) return;

    const q = query(
      collection(db, `organizations/${workspaceId}/tickets`), 
      orderBy('createdAt', 'desc')
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      // Correct ID Mapping Logic
      const mappedTickets = snapshot.docs.map(doc => ({ 
        id: doc.id, 
        ...doc.data() 
      } as TicketData));
      
      setTickets(mappedTickets);
      setLoading(false);
    }, (error) => {
      console.error("FIREBASE_RULE_BLOCK:", error);
      setLoading(false);
    });

    return () => unsubscribe();
  }, [workspaceId]);

  const handleDispatch = async () => {
    if (!isManagement) return;
    if (!targetUrl || !desc) return alert("CRITICAL: Sector data required.");
    
    setIsDispatching(true);
    try {
      const res = await fetch(`${API}/api/utils/seal`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ data: targetUrl })
      });
      const { sealed: sealedUrl } = await res.json();

      await addDoc(collection(db, `organizations/${workspaceId}/tickets`), {
        sealedTarget: sealedUrl,
        rawDescription: desc,
        status: 'OPEN',
        priority: priority,
        raisedBy: auth.currentUser?.uid,
        assignedTo: null,
        createdAt: serverTimestamp()
      });

      setTargetUrl(''); setDesc('');
      alert("Security Mission Dispatched.");
    } catch (err) {
      console.error("DISPATCH_FAILURE:", err);
    } finally {
      setIsDispatching(false);
    }
  };

  return (
    <div className="space-y-12">
      {isManagement && (
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} 
          className="glass-card p-12 rounded-[4rem] border-t-4 border-t-blue-600 shadow-2xl bg-[#151921]">
          <div className="flex items-center gap-6 mb-12 text-white">
            <Ticket size={28} className="text-blue-500" />
            <h3 className="text-3xl font-[1000] uppercase italic tracking-tighter">Dispatch <span className="text-blue-500">Center</span></h3>
          </div>
          
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
            <div className="lg:col-span-5 space-y-6">
              <input value={targetUrl} onChange={e => setTargetUrl(e.target.value)} placeholder="Target URL" className="w-full bg-[#0B0E14] border border-white/5 py-5 px-8 rounded-2xl text-white outline-none focus:border-blue-500 transition-all font-bold" />
              <div className="flex gap-2">
                {['LOW', 'MEDIUM', 'HIGH', 'CRITICAL'].map(p => (
                  <button key={p} onClick={() => setPriority(p as any)} className={`flex-1 py-3 rounded-xl text-[9px] font-black uppercase border transition-all ${priority === p ? 'bg-blue-600 border-blue-400 text-white' : 'bg-[#0B0E14] border-white/5 text-slate-500'}`}>{p}</button>
                ))}
              </div>
            </div>
            <div className="lg:col-span-7">
              <textarea value={desc} onChange={e => setDesc(e.target.value)} placeholder="Intelligence context..." className="w-full h-full min-h-[150px] bg-[#0B0E14] border border-white/5 p-6 rounded-3xl text-white outline-none focus:border-blue-500 transition-all resize-none font-bold" />
            </div>
          </div>

          <button onClick={handleDispatch} disabled={isDispatching} className="w-full mt-10 py-6 bg-blue-600 text-white rounded-[2.5rem] font-black uppercase tracking-widest text-[11px] hover:bg-blue-500 transition-all flex items-center justify-center gap-4 shadow-xl shadow-blue-600/20">
            {isDispatching ? <Loader2 className="animate-spin" size={20} /> : <Plus size={20} />} Dispatch Sealed Directive
          </button>
        </motion.div>
      )}

      <div className="space-y-8">
        <div className="flex items-center gap-4 text-white px-4">
          <Activity className="text-blue-500 w-6 h-6" />
          <h3 className="text-2xl font-[1000] uppercase italic tracking-tighter">Active <span className="text-blue-500">Missions</span></h3>
        </div>

        {loading ? (
          <div className="py-20 text-center"><Loader2 className="animate-spin mx-auto text-blue-500" /></div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-8">
            {tickets.map((t) => (
              // This call is now verified by the React.FC definition below
              <TicketCard key={t.id} ticket={t} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

// --- FIX: Using React.FC to handle internal props like 'key' ---
const TicketCard: React.FC<TicketCardProps> = ({ ticket }) => {
  const statusColors: Record<string, string> = {
    'OPEN': 'bg-blue-500/10 text-blue-500 border-blue-500/20',
    'IN_PROGRESS': 'bg-amber-500/10 text-amber-500 border-amber-500/20',
    'COMPLETED': 'bg-emerald-500/10 text-emerald-500 border-emerald-500/20'
  };

  return (
    <motion.div initial={{ opacity: 0, scale: 0.98 }} animate={{ opacity: 1, scale: 1 }}
      className="glass-card p-8 rounded-[3.5rem] border border-white/5 bg-[#151921] flex flex-col group hover:border-blue-500/40 transition-all shadow-xl">
      <div className="flex justify-between items-start mb-10">
        <div className={`px-5 py-1.5 rounded-full text-[9px] font-[1000] uppercase tracking-widest border ${statusColors[ticket.status]}`}>
          {ticket.status}
        </div>
        <div className="text-right">
          <p className="text-[10px] font-black text-slate-600 uppercase tracking-widest">TKT_{ticket.id.slice(-6).toUpperCase()}</p>
        </div>
      </div>

      <div className="flex-1 space-y-6 mb-10 px-2">
        <div className="space-y-1">
          <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Sealed Target Surface</p>
          <h4 className="text-xl font-[1000] italic text-white tracking-tighter truncate uppercase opacity-80 flex items-center gap-3">
            <Lock size={16} className="text-blue-500" /> AES-256 SEALED
          </h4>
        </div>

        <div className="p-6 bg-[#0B0E14] rounded-2xl border border-white/5 min-h-[100px]">
          <p className="text-xs font-bold text-slate-400 italic line-clamp-3 leading-relaxed">
            {ticket.rawDescription}
          </p>
        </div>
      </div>

      <div className="flex items-center gap-3 px-6 py-4 bg-white/[0.02] border border-white/5 rounded-2xl group-hover:bg-blue-600/10 transition-all">
        <div className={`w-2 h-2 rounded-full ${ticket.priority === 'CRITICAL' ? 'bg-rose-500 shadow-[0_0_10px_#f43f5e]' : 'bg-blue-500'} animate-pulse`} />
        <span className="text-[10px] font-black text-slate-500 uppercase tracking-widest group-hover:text-blue-500 transition-colors">
          Priority: {ticket.priority}
        </span>
        <ChevronRight size={14} className="ml-auto text-slate-700 group-hover:text-blue-500 transition-all" />
      </div>
    </motion.div>
  );
};

export default TicketSystem;