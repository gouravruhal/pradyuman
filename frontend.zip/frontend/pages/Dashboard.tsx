import React, { useState, useEffect, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import {
  ShieldCheck, AlertTriangle, Globe, ArrowRight, History, 
  Cpu, Lock, RefreshCw, BarChart3, Activity, Fingerprint, 
  ShieldAlert, Terminal, Zap
} from 'lucide-react';

import {
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer
} from 'recharts';

import { auth } from '../src/firebase';

const API = "http://localhost:8000";

/**
 * Maps GRC Posture Index (0-10) to the Enclave's visual language.
 *
 */
const getRiskColor = (score: number | null) => {
  if (score === null || score === undefined) return '#475569';
  if (score >= 8.0) return '#ef4444'; // Critical Status
  if (score >= 6.0) return '#f97316'; // High Warning
  if (score >= 4.0) return '#eab308'; // Medium Risk
  return '#10b981';                   // Hardened/Secure
};

const Dashboard = () => {
  const navigate = useNavigate();
  const [assets, setAssets] = useState<any[]>([]);
  const [selectedAsset, setSelectedAsset] = useState<any | null>(null);
  const [scanHistory, setScanHistory] = useState<any[]>([]);
  const [loadingAssets, setLoadingAssets] = useState(true);

  // --- 1. CRYPTO BRIDGE: Decrypt Vault Artifacts ---
  const decryptSealedData = async (sealedData: string) => {
    try {
      const res = await fetch(`${API}/api/utils/open`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ sealed: sealedData })
      });
      const result = await res.json();
      return JSON.parse(result.data);
    } catch (err) {
      console.error("Neural Decryption Link Severed:", err);
      return null;
    }
  };

  /* ---------------- FETCH & DECRYPT ENCLAVE NODES ---------------- */
  useEffect(() => {
    const fetchAssets = async () => {
      if (!auth.currentUser) return;
      try {
        const res = await fetch(`${API}/api/assets/${auth.currentUser.uid}`);
        const data = await res.json();

        if (!Array.isArray(data)) {
          setAssets([]);
          return;
        }

        const processedAssets = await Promise.all(data.map(async (asset: any) => {
          if (asset.sealedName) {
            const originalName = await decryptSealedData(asset.sealedName);
            return { ...asset, domain: originalName };
          }
          return asset;
        }));

        setAssets(processedAssets);
        if (processedAssets.length > 0) setSelectedAsset(processedAssets[0]);
      } catch (err) {
        console.error("Asset Neural Sync Failed:", err);
      } finally {
        setLoadingAssets(false);
      }
    };
    fetchAssets();
  }, []);

  /* ---------------- FETCH SCAN ARTIFACT HISTORY ---------------- */
  useEffect(() => {
    if (!selectedAsset?.assetId) return;

    const fetchScans = async () => {
      try {
        const res = await fetch(`${API}/api/assets/${selectedAsset.assetId}/scans`);
        const data = await res.json();

        if (!Array.isArray(data)) {
          setScanHistory([]);
          return;
        }

        const decryptedScans = await Promise.all(data.map(async (scan: any) => {
          if (scan.sealed_data) {
            const originalReport = await decryptSealedData(scan.sealed_data);
            return { ...scan, ...originalReport };
          }
          return scan;
        }));

        setScanHistory(decryptedScans);
      } catch (err) {
        console.error("Scan History Decryption Failed:", err);
      }
    };
    fetchScans();
  }, [selectedAsset]);

  /* ---------------- 2. DYNAMIC NEURAL TRAJECTORY LOGIC ---------------- */
  const trajectoryMatrix = useMemo(() => {
    const data = scanHistory.slice().reverse().map((scan, i) => ({
      name: `Pt ${i + 1}`,
      risk: scan.grc_posture_index ?? scan.riskScore ?? 0
    }));

    // THE FIX: Max * 1.5 LOGIC
    // Defaulting to 0.1 fallback to prevent division errors if all data is zero
    const maxRiskInSet = Math.max(...data.map(d => d.risk), 0.1);
    const yAxisDynamicLimit = maxRiskInSet * 1.5; 

    return { data, yAxisDynamicLimit };
  }, [scanHistory]);

  const latestRisk = scanHistory[0]?.grc_posture_index ?? scanHistory[0]?.riskScore ?? null;

  return (
    <div className="space-y-10 pb-20 px-4 max-w-[1600px] mx-auto selection:bg-blue-500/30">
      
      {/* 1. STATUS HEADER */}
      <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} 
        className="flex flex-col md:flex-row md:items-end justify-between gap-6 border-b border-white/5 pb-10">
        <div className="space-y-4">
          <div className="flex items-center gap-3 text-[10px] font-black uppercase tracking-[0.4em] text-blue-500">
            <Activity className="w-4 h-4 animate-pulse" /> PRADYUMAN NEURAL OPS v4.5
          </div>
          <h1 className="text-6xl font-[1000] uppercase italic tracking-tighter leading-none text-white">
            Security <span className="text-blue-500">Intelligence</span>
          </h1>
          <p className="text-slate-500 font-medium italic">Enclave-wide vulnerability telemetry and risk posture monitoring.</p>
        </div>
        <div className="flex items-center gap-4 bg-[#151921] p-1.5 rounded-[2rem] border border-white/5 shadow-2xl">
          <div className="px-8 py-3 text-center border-r border-white/5">
             <p className="text-[9px] font-black text-slate-600 uppercase tracking-widest">Link</p>
             <p className="text-xs font-bold text-emerald-500 flex items-center gap-2">
               <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-ping" /> SECURE
             </p>
          </div>
          <div className="px-8 py-3 text-center">
             <p className="text-[9px] font-black text-slate-600 uppercase tracking-widest">Vault Protocol</p>
             <p className="text-xs font-bold text-blue-500 italic uppercase">AES-256-GCM</p>
          </div>
        </div>
      </motion.div>

      {/* 2. TRACKED ENCLAVE NODES */}
      <div className="glass-card p-10 rounded-[3.5rem] border border-white/5 relative overflow-hidden bg-[#151921]/40 backdrop-blur-sm shadow-2xl">
        <div className="absolute top-0 right-0 p-8 opacity-[0.03]"><Globe size={140} /></div>
        <div className="flex items-center justify-between mb-10">
           <h3 className="text-[11px] font-black flex items-center gap-3 uppercase tracking-[0.4em] text-blue-500 relative z-10 italic">
             <Cpu size={16} /> Asset Matrix Nodes
           </h3>
           <span className="text-[8px] font-bold text-slate-700 uppercase tracking-widest bg-white/5 px-4 py-1.5 rounded-full border border-white/5">
             Verified Assets: {assets.length}
           </span>
        </div>

        {loadingAssets ? (
          <div className="flex items-center gap-4 text-xs font-bold text-slate-600 animate-pulse uppercase tracking-widest py-6">
            <RefreshCw className="animate-spin w-5 h-5 text-blue-500" /> Synchronizing Neural Links...
          </div>
        ) : assets.length === 0 ? (
          <div className="bg-[#0B0E14] p-16 rounded-[3rem] text-center border-2 border-dashed border-white/5 opacity-40">
             <Fingerprint size={56} className="mx-auto mb-6 text-slate-800" />
             <p className="text-xs font-[1000] uppercase italic tracking-tighter text-slate-500 leading-relaxed">No active nodes registered in this workspace.<br/>Initialize an audit node to begin monitoring.</p>
          </div>
        ) : (
          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-5 relative z-10">
            {assets.map(asset => (
              <button
                key={asset.assetId}
                onClick={() => setSelectedAsset(asset)}
                className={`p-6 rounded-[2rem] text-[10px] font-[1000] uppercase tracking-widest transition-all border duration-500
                ${selectedAsset?.assetId === asset.assetId
                    ? 'bg-blue-600 text-white border-blue-400 shadow-2xl shadow-blue-600/30 scale-[1.05]'
                    : 'bg-[#0B0E14] border-white/5 text-slate-600 hover:border-blue-500/20 hover:text-slate-300'}`}
              >
                <div className="flex flex-col items-center gap-3">
                   <Zap size={14} className={selectedAsset?.assetId === asset.assetId ? 'text-white animate-pulse' : 'text-slate-800'} />
                   <span className="truncate
                       <Tooltip
                    contentStyle={{
                      background: '#0B0E14',
                      border: '1px solid #ffffff10',
                      borderRadius: '24px',
                      fontSize: '11px',
                      fontWeight: 1000,
                      padding: '20px',
                      boxShadow: '0 25px 50px -12px rgba(0, 0, 0, 0.7)'
                    }}
                  />
                  <Area
                    type="monotone"
                    dataKey="risk"
                    stroke={getRiskColor(latestRisk)}
                    strokeWidth={5}
                    fill="url(#riskFill)"
                    animationDuration={3000}
                    strokeLinecap="round"
                  />
                </AreaChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-full flex flex-col items-center justify-center opacity-5 space-y-6">
                <BarChart3 size={120} className="text-slate-400" />
                <p className="text-[10px] font-black uppercase tracking-[1em] text-slate-400">Awaiting Telemetry</p>
              </div>
            )}
          </div>
        </div>

        {/* 5. RECENT NEURAL ARTIFACTS SIDEBAR */}
        <div className="lg:col-span-4 glass-card p-12 rounded-[4rem] border border-white/5 flex flex-col bg-[#151921] shadow-xl">
          <h3 className="text-[10px] font-black uppercase tracking-[0.4em] text-slate-600 mb-12 flex items-center gap-4 italic">
             <History size={16} className="text-blue-500" /> Trace Ledger
          </h3>
          <div className="space-y-4 flex-1">
            {scanHistory.slice(0, 5).map((scan, i) => (
              <motion.div key={i} whileHover={{ x: 6 }} onClick={() => navigate('/history')}
                className="flex items-center justify-between group cursor-pointer bg-[#0B0E14]/50 p-6 rounded-[2.5rem] border border-white/5 hover:border-blue-500/30 transition-all shadow-inner">
                <div className="space-y-2">
                  <div className="text-[11px] font-[1000] uppercase italic text-white tracking-tighter leading-none">
                    {scan.scan_id ? scan.scan_id.substring(0, 12) : `NODE-${i}`}
                  </div>
                  <div className="text-[8px] font-black text-slate-700 uppercase tracking-widest">{scan.target || "Sealed_Node"}</div>
                </div>
                <div className="text-right">
                  <div className="text-2xl font-[1000] italic tracking-tighter leading-none" 
                    style={{ color: getRiskColor(scan.grc_posture_index ?? scan.riskScore) }}>
                    {scan.grc_posture_index ?? scan.riskScore ?? '0.00'}
                  </div>
                  <p className="text-[7px] font-black text-slate-800 uppercase tracking-widest mt-1.5">Neural Score</p>
                </div>
              </motion.div>
            ))}
            
            {scanHistory.length === 0 && (
               <div className="flex-1 flex flex-col items-center justify-center opacity-10 space-y-6">
                  <Terminal size={40} className="text-slate-500" />
                  <p className="text-[8px] font-black uppercase tracking-[0.5em] text-slate-500">Backlog Silent</p>
               </div>
            )}
          </div>
          <button
            onClick={() => navigate('/history')}
            className="mt-12 w-full py-6 rounded-[2.5rem] bg-white/[0.02] border border-white/5 text-[9px] font-black uppercase tracking-[0.3em] text-slate-500 flex items-center justify-center gap-4 hover:bg-blue-600 hover:text-white transition-all shadow-xl group italic active:scale-95">
            History Vault <ArrowRight size={14} className="group-hover:translate-x-1 transition-transform" />
          </button>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;