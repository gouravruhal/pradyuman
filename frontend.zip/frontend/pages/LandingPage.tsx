import React, { useRef, useMemo, useState, useEffect } from 'react';
import { motion, useScroll, useTransform, useSpring, AnimatePresence } from 'framer-motion';
import { Link } from 'react-router-dom';
import { 
  Shield, 
  Activity, 
  BrainCircuit, 
  ChevronDown, 
  ArrowRight, 
  Sun, 
  Moon 
} from 'lucide-react';


  return (
    <motion.div style={{ y, opacity, scale }} className="w-full max-w-3xl mx-auto will-change-transform">
      <div className="bg-[var(--glass-bg)] backdrop-blur-2xl rounded-[2rem] p-6 border border-[var(--border-color)] shadow-2xl overflow-hidden relative">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <div className="flex gap-1.5">
              <div className="w-2.5 h-2.5 rounded-full bg-red-500/30 border border-red-500/50" />
              <div className="w-2.5 h-2.5 rounded-full bg-amber-500/30 border border-amber-500/50" />
              <div className="w-2.5 h-2.5 rounded-full bg-emerald-500/30 border border-emerald-500/50" />
            </div>
            <span className="text-[9px] font-mono text-[var(--text-muted)] uppercase tracking-widest italic">enclave_uplink.v4</span>
          </div>
          <div className="px-3 py-1 bg-[var(--primary-glow)] rounded-full border border-[var(--primary)]/20 flex items-center gap-2">
            <span className="w-1 h-1 rounded-full bg-[var(--primary)] animate-ping" />
            <span className="text-[8px] font-black text-[var(--primary)] uppercase tracking-widest">Live_Matrix</span>
          </div>
        </div>

/**
 * SUB-COMPONENT: ComplianceVisual
 */
const ComplianceVisual: React.FC<VisualProps> = ({ progress }) => {
  const opacity = useTransform(progress, [0, 0.2, 0.8, 1], [0, 1, 1, 0]);
  const scale = useTransform(progress, [0, 0.2, 0.8, 1], [0.95, 1, 1, 0.95]);
  
  const tiers = [
    { name: 'OWASP Top 10', color: 'var(--tier-solo)' },
    { name: 'NIST CSF', color: 'var(--tier-alpha)' },
    { name: 'ISO 27001', color: 'var(--tier-corp)' }
  ];

  return (
    <motion.div style={{ opacity, scale }} className="w-full max-w-5xl mx-auto py-8 will-change-transform">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {tiers.map((item) => (
          <div key={item.name} className="bg-[var(--glass-bg)] backdrop-blur-2xl p-8 rounded-[2rem] border border-[var(--border-color)] shadow-xl flex flex-col items-center text-center group hover:scale-[1.02] transition-all duration-500" style={{ borderBottom: `4px solid ${item.color}` }}>
            <div className="w-14 h-14 rounded-2xl bg-[var(--bg-nested)] flex items-center justify-center mb-6 shadow-lg">
               <Shield className="w-7 h-7" style={{ color: item.color }} />
            </div>
            <h3 className="text-base font-black text-[var(--text-main)] mb-2 uppercase tracking-tighter italic">{item.name}</h3>
            <p className="text-[11px] text-[var(--text-muted)] leading-relaxed font-medium">Autonomous control mapping and gap analysis with zero drift.</p>
          </div>
        ))}
      </div>
    </motion.div>
  );
};

/**
 * SUB-COMPONENT: ScrollIndicatorDot
 */
const ScrollIndicatorDot: React.FC<DotProps> = ({ index, progress }) => {
  const targetValue = index * 0.333;
  const height = useTransform(progress, [targetValue - 0.1, targetValue, targetValue + 0.1], [6, 24, 6]);
  const backgroundColor = useTransform(progress, [targetValue - 0.1, targetValue, targetValue + 0.1], ["var(--text-muted)", "var(--primary)", "var(--text-muted)"]);
  const labelOpacity = useTransform(progress, [targetValue - 0.05, targetValue, targetValue + 0.05], [0, 1, 0]);
  const labels = ["Intro", "Audit", "Forge", "Logic"];

  return (
    <div className="flex items-center justify-end gap-3 group relative pointer-events-auto">
      <motion.span style={{ opacity: labelOpacity }} className="text-[9px] font-black uppercase tracking-[0.3em] text-[var(--primary)] whitespace-nowrap hidden md:block italic">
        {labels[index]}
      </motion.span>
      <motion.div style={{ height, backgroundColor }} className="w-1 rounded-full shadow-lg" />
    </div>
  );
};

/**
 * MAIN COMPONENT: LandingPage
 */
const LandingPage: React.FC = () => {
  const [theme, setTheme] = useState<'dark' | 'light'>(() => {
    return (localStorage.getItem('theme') as 'dark' | 'light') || 'dark';
  });
  
  const containerRef = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({ container: containerRef });
  const smoothProgress = useSpring(scrollYProgress, { stiffness: 70, damping: 24, restDelta: 0.001 });

  const heroOpacity = useTransform(smoothProgress, [0, 0.15, 0.25], [1, 1, 0]);
  const heroScale = useTransform(smoothProgress, [0, 0.2], [1, 0.95]);

  // Unified Theme Toggle Logic
  useEffect(() => {
    if (theme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
    localStorage.setItem('theme', theme);
  }, [theme]);

  const toggleTheme = () => setTheme(prev => prev === 'dark' ? 'light' : 'dark');

  return (
    <div ref={containerRef} className="relative h-screen overflow-y-auto snap-y snap-mandatory scroll-smooth hide-scrollbar bg-[var(--bg-main)] text-[var(--text-main)]">
      
      {/* Navigation Layer */}
      <nav className="fixed top-0 left-0 w-full z-[100] px-8 md:px-14 py-8 md:py-10 flex items-center justify-between pointer-events-none">
        <div className="text-2xl font-[900] tracking-tighter text-[var(--text-main)] flex items-center gap-3 pointer-events-auto italic uppercase">
          <Shield className="w-7 h-7 text-[var(--primary)]" /> Pradyuman
        </div>
        
        <div className="flex items-center gap-5 pointer-events-auto">
          <button onClick={toggleTheme} className="p-3 bg-[var(--glass-bg)] border border-[var(--border-color)] text-[var(--primary)] rounded-2xl shadow-xl hover:scale-110 transition-all backdrop-blur-md">
            {theme === 'dark' ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
          </button>

          <Link to="/login" className="bg-[var(--primary)] text-[var(--text-inverse)] px-8 py-3.5 rounded-2xl font-black text-[10px] uppercase tracking-widest shadow-xl shadow-[var(--primary-glow)] hover:translate-y-[-2px] transition-all">
            get started
          </Link>
        </div>
      </nav>

      {/* Section 1: Hero */}
      <section className="relative h-screen flex flex-col items-center justify-center text-center px-6 snap-start shrink-0 overflow-hidden">
        <motion.div style={{ opacity: heroOpacity, scale: heroScale }} className="max-w-4xl space-y-6 will-change-transform z-10">
          <div className="inline-flex items-center gap-3 px-4 py-1.5 bg-[var(--primary-glow)] border border-[var(--primary)]/20 rounded-full text-[var(--primary)] font-black text-[10px] uppercase tracking-widest mx-auto">
            <span className="w-1.5 h-1.5 rounded-full bg-[var(--primary)] animate-pulse" />
            Neural Infrastructure v4.2
          </div>
          <h1 className="text-5xl md:text-7xl lg:text-8xl font-[1000] tracking-tighter text-[var(--text-main)] mb-2 leading-[0.9] uppercase italic">
            Modular.<br />
            Intelligent.<br />
            <span className="text-[var(--primary)]">Verifiable.</span>
          </h1>
          <p className="text-sm md:text-lg text-[var(--text-muted)] max-w-2xl mx-auto leading-relaxed font-bold italic opacity-80">
            Advanced security assessment engine bridging technical complexity with regulatory compliance.
          </p>
          <motion.div animate={{ y: [0, 10, 0] }} transition={{ repeat: Infinity, duration: 2.5 }} className="text-[var(--text-muted)] pt-6 flex justify-center opacity-30">
             <ChevronDown className="w-8 h-8" />
          </motion.div>
        </motion.div>
        {/* Dynamic Background Glow */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-[var(--primary)] opacity-[0.03] blur-[120px] rounded-full -z-0" />
      </section>

      {/* Section 2: Monitoring */}
      <section className="relative h-screen flex items-center justify-center px-8 md:px-24 snap-start shrink-0 overflow-hidden bg-[var(--bg-nested)]">
        <div className="w-full max-w-7xl grid grid-cols-1 lg:grid-cols-2 gap-12 md:gap-20 items-center">
          <motion.div 
            style={{ 
              opacity: useTransform(smoothProgress, [0.15, 0.3, 0.45, 0.6], [0, 1, 1, 0]),
              x: useTransform(smoothProgress, [0.15, 0.3, 0.45, 0.6], [-40, 0, 0, -40])
            }}
            className="space-y-6 will-change-transform"
          >
            <div className="w-12 h-12 rounded-2xl bg-[var(--primary-glow)] flex items-center justify-center border border-[var(--primary)]/20 shadow-lg">
               <Activity className="text-[var(--primary)] w-6 h-6" />
            </div>
            <h2 className="text-5xl md:text-6xl font-black text-[var(--text-main)] tracking-tighter uppercase italic leading-none">
              Neural <br />Monitoring.
            </h2>
            <p className="text-[var(--text-muted)] text-base md:text-lg leading-relaxed font-bold italic">
              Automated surveillance jo subdomains aur TLS integrity ko real-time analyze karke exposure detect karta hai.
            </p>
          </motion.div>
          <MonitoringVisual progress={useTransform(smoothProgress, [0.2, 0.5], [0, 1])} />
        </div>
      </section>

      {/* Section 3: Compliance */}
      <section className="relative h-screen flex flex-col items-center justify-center px-8 md:px-24 snap-start shrink-0 overflow-hidden bg-[var(--bg-main)]">
        <motion.div 
           style={{ opacity: useTransform(smoothProgress, [0.45, 0.6, 0.75, 0.9], [0, 1, 1, 0]), y: useTransform(smoothProgress, [0.45, 0.6], [30, 0]) }}
           className="text-center mb-10 max-w-3xl will-change-transform"
        >
           <h2 className="text-5xl md:text-7xl font-black text-[var(--text-main)] tracking-tighter mb-4 uppercase italic leading-none">Compliance <br />Forge.</h2>
           <p className="text-[var(--text-muted)] text-base md:text-lg font-bold italic">
             Raw technical metadata ko NIST CSF aur ISO standards mein autonomously forge karne ka intelligent workflow.
           </p>
        </motion.div>
        <ComplianceVisual progress={useTransform(smoothProgress, [0.5, 0.8], [0, 1])} />
      </section>

      {/* Section 4: Intelligence */}
      <section className="relative h-screen flex items-center justify-center px-8 md:px-24 snap-start shrink-0 overflow-hidden bg-[var(--bg-nested)]">
        <div className="w-full max-w-7xl grid grid-cols-1 lg:grid-cols-2 gap-12 md:gap-20 items-center">
          <motion.div 
            style={{ opacity: useTransform(smoothProgress, [0.75, 0.9, 1], [0, 1, 1]), scale: useTransform(smoothProgress, [0.75, 0.9], [0.9, 1]) }}
            className="flex justify-center will-change-transform order-2 lg:order-1"
          >
             <div className="relative w-64 h-64 md:w-[400px] md:h-[400px] flex flex-col items-center justify-center">
                <svg className="w-full h-full -rotate-90 filter drop-shadow-[0_0_20px_var(--primary-glow)]">
                   <circle cx="50%" cy="50%" r="42%" stroke="var(--border-color)" strokeWidth="4%" fill="transparent" />
                   <motion.circle 
                     cx="50%" cy="50%" r="42%" stroke="var(--primary)" strokeWidth="4%" fill="transparent" 
                     strokeLinecap="round" strokeDasharray="264%"
                     style={{ strokeDashoffset: useTransform(smoothProgress, [0.8, 1], ["264%", "21%"]) }}
                   />
                </svg>
                <div className="absolute inset-0 flex flex-col items-center justify-center text-center">
                   <span className="text-6xl md:text-8xl font-black text-[var(--text-main)] leading-none italic tracking-tighter">92%</span>
                   <span className="text-[9px] font-black text-[var(--primary)] uppercase tracking-[0.4em] mt-3">Audit_Ready</span>
                </div>
             </div>
          </motion.div>

          <motion.div 
            style={{ opacity: useTransform(smoothProgress, [0.75, 0.9, 1], [0, 1, 1]), x: useTransform(smoothProgress, [0.75, 0.9], [40, 0]) }}
            className="space-y-8 will-change-transform order-1 lg:order-2"
          >
             <div className="inline-flex p-5 bg-indigo-600/10 rounded-2xl border border-indigo-500/20 shadow-xl">
                <BrainCircuit className="w-10 h-10 text-indigo-400" />
             </div>
             <h2 className="text-5xl md:text-7xl font-black text-[var(--text-main)] tracking-tighter leading-[0.9] uppercase italic">Audit <br />Logic.</h2>
             <p className="text-[var(--text-muted)] text-base md:text-xl leading-relaxed font-bold italic">
               Risk delta jo engineers aur compliance officers dono ki common interface language samajhta hai.
             </p>
             <div className="flex pt-4">
                <Link to="/login" className="bg-[var(--primary)] text-[var(--text-inverse)] px-12 py-5 rounded-2xl font-black text-xs uppercase tracking-widest shadow-2xl shadow-[var(--primary-glow)] hover:scale-105 active:scale-95 group flex items-center gap-4">
                   Enter Enclave <ArrowRight className="w-5 h-5 group-hover:translate-x-2 transition-transform" />
                </Link>
             </div>
          </motion.div>
        </div>
      </section>

      {/* Floating Indicator Layer */}
      <div className="fixed bottom-10 right-10 z-[110] flex flex-col items-end gap-5 p-4 pointer-events-none">
          {[0, 1, 2, 3].map((i) => (
            <ScrollIndicatorDot key={i} index={i} progress={smoothProgress} />
          ))}
      </div>
    </div>
  );
};

export default LandingPage;