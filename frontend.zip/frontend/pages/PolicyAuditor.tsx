import React, { useState, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { FileSearch, FileUp, CheckCircle2, Loader2, Zap, Target } from 'lucide-react';

const API = "http://localhost:8000";

const PolicyAuditor = ({ workspaceId, userId }: any) => {
  const [isScanning, setIsScanning] = useState(false);
  const [uploadedFileName, setUploadedFileName] = useState<string | null>(null);
  const [analysis, setAnalysis] = useState<any>(null);
  const [framework, setFramework] = useState('ISO 27001');
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setUploadedFileName(file.name);
      
      const formData = new FormData();
      formData.append("file", file);
      formData.append("workspaceId", workspaceId);
      formData.append("userId", userId);
      formData.append("standard", framework);

      setIsScanning(true);
      try {
        const res = await fetch(`${API}/api/policies/upload`, {
          method: 'POST',
          body: formData
        });
        const data = await res.json();
        setAnalysis(data.analysis);
      } catch (err) {
        console.error("Audit Link Severed:", err);
      } finally {
        setIsScanning(false);
      }
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
      <div className="lg:col-span-7">
        <div className="glass-card p-12 rounded-[3.5rem] border border-white/5 bg-[#151921]/50">
          <div className="flex items-center gap-6 mb-12">
            <div className="p-4 bg-blue-500/10 rounded-2xl"><FileSearch className="text-blue-500" size={32} /></div>
            <div>
              <h3 className="text-3xl font-[900] uppercase tracking-tighter text-white italic">Audit <span className="text-blue-500">Ingestion</span></h3>
              <p className="text-sm text-slate-500 font-bold">Analyze legacy artifacts via Llama-70B.</p>
            </div>
          </div>

          <div onClick={() => fileInputRef.current?.click()} className={`w-full h-80 border-2 border-dashed rounded-[3rem] transition-all flex flex-col items-center justify-center gap-6 cursor-pointer group ${uploadedFileName ? 'border-emerald-500/40 bg-emerald-500/5' : 'border-white/5 hover:border-blue-500/40 hover:bg-blue-500/5'}`}>
            <input type="file" ref={fileInputRef} className="hidden" accept=".pdf" onChange={handleFileUpload} />
            <div className={`p-6 rounded-3xl ${uploadedFileName ? 'bg-emerald-500 text-white' : 'bg-white/5 text-slate-600 group-hover:text-blue-500 transition-colors'}`}>
              {uploadedFileName ? <CheckCircle2 size={48} /> : <FileUp size={48} />}
            </div>
            <p className="font-black uppercase tracking-widest text-[10px] text-slate-400 px-10 text-center truncate w-full italic">
              {uploadedFileName || 'Drop Security Policy PDF Artifact'}
            </p>
          </div>

          <div className="grid grid-cols-3 gap-4 mt-10">
            {['ISO 27001', 'ISO 42001', 'NIST CSF'].map(f => (
              <button key={f} onClick={() => setFramework(f)} className={`py-4 rounded-2xl text-[9px] font-[1000] uppercase tracking-widest border transition-all ${framework === f ? 'bg-blue-600 border-transparent text-white shadow-lg' : 'border-white/5 text-slate-500 hover:border-blue-500/30'}`}>{f}</button>
            ))}
          </div>
        </div>
      </div>

      <div className="lg:col-span-5">
        <div className="glass-card p-12 rounded-[3.5rem] h-full border border-white/5 flex flex-col bg-[#151921]/30 backdrop-blur-xl">
          <h4 className="text-[10px] font-black text-slate-500 uppercase tracking-[0.4em] mb-12">Neural Compliance Matrix</h4>
          <AnimatePresence mode="wait">
            {isScanning ? (
              <div className="flex-1 flex flex-col items-center justify-center text-center gap-8">
                <Loader2 className="w-16 h-16 text-blue-500 animate-spin" />
                <p className="text-[10px] font-black uppercase tracking-[0.3em] text-blue-500 animate-pulse">Extracting Intelligence...</p>
              </div>
            ) : analysis ? (
              <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-12">
                <div className="flex items-end gap-5">
                  <span className="text-8xl font-[1000] tracking-tighter text-white italic">{analysis.compliance_score}%</span>
                  <div className="mb-4"><span className="text-[10px] font-black text-emerald-500 uppercase tracking-widest block">Readiness</span></div>
                </div>
                <div className="space-y-4">
                  {analysis.key_gaps?.map((gap: string, i: number) => (
                    <div key={i} className="p-6 rounded-[2rem] border border-rose-500/20 bg-rose-500/5 flex items-center justify-between">
                      <h5 className="font-black text-[10px] uppercase text-rose-500 tracking-tight">{gap}</h5>
                      <span className="text-[8px] font-black uppercase text-rose-600 bg-rose-600/10 px-3 py-1 rounded-full">Missing</span>
                    </div>
                  ))}
                </div>
              </motion.div>
            ) : (
              <div className="flex-1 flex flex-col items-center justify-center opacity-10 gap-8">
                <Target size={120} className="text-slate-500" />
                <p className="text-xl font-[1000] uppercase italic tracking-widest text-slate-400">Enclave Idle</p>
              </div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
};

export default PolicyAuditor;