import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  History, Search, Download, FileText, Bug, ChevronRight,
  Database, Network, Scale, X, ArrowRight,
  ShieldAlert, Activity, CheckCircle2, Lock, Trash2, RefreshCw,
  Clock, BarChart3, Terminal,
  Globe
} from 'lucide-react';
import { db } from '../src/firebase';
import { collection, query, onSnapshot, orderBy, doc, deleteDoc, where } from 'firebase/firestore';

const API = "http://localhost:8000";

const ArchiveVault = ({ workspaceId }: { workspaceId: string }) => {
  const [activeTab, setActiveTab] = useState<'SCANS' | 'TICKETS'>('SCANS');
  const [searchQuery, setSearchQuery] = useState('');
  const [artifacts, setArtifacts] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedArtifact, setSelectedArtifact] = useState<any | null>(null);
  const [isDecryptingDetail, setIsDecryptingDetail] = useState(false);

  // --- CRYPTO BRIDGE: Open AES-256 Artifacts ---
  const decryptData = async (sealedData: string) => {
    try {
      const res = await fetch(`${API}/api/utils/open`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ sealed: sealedData })
      });
      const result = await res.json();
      return JSON.parse(result.data); 
    } catch (err) {
      console.error("Vault Decryption Link Severed:", err);
      return null;
    }
  };

  // ---------------------------------------------------------
  // DATA SYNC: Matching main.py Data Structure
  // ---------------------------------------------------------
  useEffect(() => {
    if (!workspaceId) return;
    setLoading(true);

    // Logic Fix: Backend stores scans in root 'scans' collection
    const collectionName = activeTab === 'SCANS' ? 'scans' : 'tickets';
    const timeField = activeTab === 'SCANS' ? 'startedAt' : 'createdAt';

    const q = query(
      collection(db, activeTab === 'SCANS' ? 'scans' : `organizations/${workspaceId}/tickets`), 
      where(activeTab === 'SCANS' ? 'workspaceId' : 'status', '!=', 'DELETE_PENDING'), // Dummy filter for matching backend fields
      orderBy(timeField, 'desc')
    );

    // Filter by workspaceId specifically for Scans
    const finalQuery = activeTab === 'SCANS' 
      ? query(collection(db, 'scans'), where('workspaceId', '==', workspaceId), orderBy('startedAt', 'desc'))
      : query(collection(db, `organizations/${workspaceId}/tickets`), orderBy('createdAt', 'desc'));

    const unsubscribe = onSnapshot(finalQuery, (snapshot) => {
      const docs = snapshot.docs.map(d => ({ id: d.id, ...d.data() }));
      setArtifacts(docs);
      setLoading(false);
    }, (err) => {
      console.error("Firebase Access Denied:", err);
      setLoading(false);
    });

    return () => unsubscribe();
  }, [workspaceId, activeTab]);

  // ---------------------------------------------------------
  // LOGIC: Detail Expansion & Decryption
  // ---------------------------------------------------------
  const handleViewDetails = async (artifact: any) => {
    // If scanning artifact has sealed_data, open it
    if (artifact.sealed_data) {
      setIsDecryptingDetail(true);
      const fullManifest = await decryptData(artifact.sealed_data);
      setSelectedArtifact({ ...artifact, ...fullManifest });
      setIsDecryptingDetail(false);
    } else {
      setSelectedArtifact(artifact);
    }
  };

  const filteredArtifacts = artifacts.filter(item => 
    item.id.toLowerCase().includes(searchQuery.toLowerCase()) || 
    item.target?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="space-y-12 max-w-[1600px] mx-auto pb-32 px-6 lg:px-10">
      
      {/* HEADER SECTION */}
      <div className="flex flex-col xl:flex-row xl:items-center justify-between gap-12 border-b border-white/5 pb-12">
        <div className="space-y-4">
          <div className="flex items-center gap-3 text-[11px] font-black uppercase tracking-[0.4em] text-blue-500">
             <Lock size={14} /> Secure Archive Vault
          </div>
          <h1 className="text-6xl font-[1000] text-white tracking-tighter uppercase italic leading-none">
            Master <span className="text-blue-500">Artifacts</span>
          </h1>
          <p className="text-slate-500 font-medium text-lg flex items-center gap-3 italic">
             <History className="w-5 h-5 text-blue-500" /> Immutable ledger for AES-256 crypto-sealed security traces.
          </p>
        </div>

        <div className="flex bg-[#151921] p-1.5 rounded-[2.5rem] border border-white/5 shadow-2xl min-w-[400px]">
          {['SCANS', 'TICKETS'].map((tab: any) => (
            <button key={tab} onClick={() => setActiveTab(tab)}
              className={`flex-1 px-8 py-4 rounded-[2rem] text-[10px] font-black uppercase tracking-widest transition-all duration-500 flex items-center justify-center gap-3 ${activeTab === tab ? 'bg-blue-600 text-white shadow-xl' : 'text-slate-500 hover:text-white'}`}>
              {tab === 'SCANS' ? <Bug size={16} /> : <Terminal size={16} />} {tab}
            </button>
          ))}
        </div>
      </div>

      {/* FILTER SUITE */}
      <div className="glass-card p-4 rounded-[3rem] border border-white/5 bg-[#151921]/50 backdrop-blur-md">
         <div className="relative w-full">
            <Search className="absolute left-8 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-500" />
            <input type="text" placeholder={`Search by Scan ID or Target Domain...`} value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-transparent border-none py-6 pl-20 pr-8 text-sm font-bold text-white placeholder:text-slate-600 focus:ring-0 outline-none" />
         </div>
      </div>

      {/* ARTIFACT DATA TABLE */}
      <div className="glass-card rounded-[4rem] overflow-hidden border border-white/5 shadow-2xl bg-[#0B0E14]/40">
         <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse min-w-[1200px]">
               <thead>
                  <tr className="text-[11px] font-black text-slate-500 uppercase tracking-[0.4em] border-b border-white/5 bg-white/[0.02]">
                     <th className="px-12 py-10 text-blue-500">Identifier</th>
                     <th className="px-12 py-10">Surface Target</th>
                     <th className="px-12 py-10">Neural Status</th>
                     <th className="px-12 py-10">Posture Index</th>
                     <th className="px-12 py-10 text-right">Operation</th>
                  </tr>
               </thead>
               <tbody className="divide-y divide-white/5">
                  {loading ? (
                    <tr><td colSpan={5} className="py-32 text-center text-slate-600 font-black uppercase tracking-widest animate-pulse">Syncing Enclave Vault...</td></tr>
                  ) : filteredArtifacts.map((item) => (
                    <motion.tr key={item.id} initial={{ opacity: 0 }} animate={{ opacity: 1 }} onClick={() => handleViewDetails(item)}
                      className="hover:bg-blue-600/[0.03] cursor-pointer group transition-all border-l-2 border-transparent hover:border-blue-600">
                       <td className="px-12 py-10 font-mono text-xs font-black text-slate-400 group-hover:text-blue-500">
                         {item.scanId || item.id.slice(0,14).toUpperCase()}
                       </td>
                       <td className="px-12 py-10">
                          <p className="text-base font-[1000] text-white uppercase italic tracking-tighter leading-none">{item.target || "Sealed_Node"}</p>
                          <p className="text-[8px] font-black text-slate-600 uppercase tracking-widest mt-2">{new Date(item.startedAt?.toDate()).toLocaleString()}</p>
                       </td>
                       <td className="px-12 py-10">
                          <span className={`px-4 py-1.5 rounded-full text-[9px] font-black uppercase border ${item.status === 'completed' ? 'border-emerald-500/20 text-emerald-500 bg-emerald-500/5' : 'border-amber-500/20 text-amber-500 bg-amber-500/5'}`}>
                            {item.status}
                          </span>
                       </td>
                       <td className="px-12 py-10 text-4xl font-[1000] italic tracking-tighter text-blue-500/30 group-hover:text-blue-500 transition-colors">
                         {item.riskScore || item.grc_posture_index || '00'}
                       </td>
                       <td className="px-12 py-10 text-right">
                          <ChevronRight className="ml-auto text-slate-800 group-hover:text-blue-500 group-hover:translate-x-2 transition-all" />
                       </td>
                    </motion.tr>
                  ))}
               </tbody>
            </table>
         </div>
      </div>

      {/* DETAIL VIEW MODAL (Decrypted Intelligence) */}
      <AnimatePresence>
        {(selectedArtifact || isDecryptingDetail) && (
          <div className="fixed inset-0 z-[200] flex items-center justify-center p-10 backdrop-blur-2xl">
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={() => setSelectedArtifact(null)} className="absolute inset-0 bg-[#0B0E14]/90" />
            <motion.div initial={{ scale: 0.95, y: 20 }} animate={{ scale: 1, y: 0 }} exit={{ scale: 0.95 }}
              className="relative w-full max-w-7xl glass-card bg-[#151921] rounded-[4rem] border border-white/10 shadow-2xl overflow-hidden flex flex-col h-[90vh]">
              
              {isDecryptingDetail ? (
                <div className="flex-1 flex flex-col items-center justify-center space-y-8">
                  <RefreshCw className="w-20 h-20 text-blue-500 animate-spin" />
                  <p className="text-[12px] font-black uppercase tracking-[0.6em] text-blue-500 animate-pulse">Decrypting Neural Artifact...</p>
                </div>
              ) : (
                <>
                  <div className="px-16 py-12 border-b border-white/5 flex items-center justify-between bg-gradient-to-r from-blue-600/10 to-transparent">
                     <div className="flex items-center gap-6">
                        <div className="p-4 bg-blue-600 rounded-3xl shadow-xl shadow-blue-500/20"><Activity size={32} className="text-white" /></div>
                        <div>
                          <h2 className="text-5xl font-[1000] uppercase italic tracking-tighter text-white">Neural <span className="text-blue-500">Manifest</span></h2>
                          <p className="text-[10px] font-black text-slate-500 uppercase tracking-[0.4em] mt-2 italic">Integrity Check: SHA-256 Verified Ledger</p>
                        </div>
                     </div>
                     <button onClick={() => setSelectedArtifact(null)} className="p-4 hover:bg-rose-500/10 hover:text-rose-500 rounded-full transition-all text-slate-600"><X size={40} /></button>
                  </div>

                  <div className="flex-1 overflow-y-auto p-16 space-y-12">
                     <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
                        <div className="p-10 rounded-[3rem] bg-[#0B0E14] border border-white/5 relative group overflow-hidden">
                           <Globe className="absolute top-0 right-0 p-8 opacity-5 text-blue-500" size={120} />
                           <p className="text-[9px] font-black text-slate-500 uppercase tracking-widest mb-6">Target Surface</p>
                           <p className="text-3xl font-[1000] italic text-white uppercase tracking-tighter">{selectedArtifact.target}</p>
                        </div>
                        <div className="p-10 rounded-[3rem] bg-[#0B0E14] border border-white/5 text-center">
                           <p className="text-[9px] font-black text-slate-500 uppercase tracking-widest mb-6">GRC Risk Index</p>
                           <p className="text-8xl font-[1000] italic text-blue-500 tracking-tighter leading-none">{selectedArtifact.riskScore || selectedArtifact.grc_posture_index}</p>
                        </div>
                        <div className="p-10 rounded-[3rem] bg-blue-600 text-white shadow-2xl shadow-blue-600/20">
                           <Clock className="mb-6 opacity-40" size={32} />
                           <p className="text-[9px] font-black text-white/60 uppercase tracking-widest mb-2">Finalized At</p>
                           <p className="text-xl font-black italic uppercase leading-tight">{new Date(selectedArtifact.startedAt?.toDate()).toLocaleString()}</p>
                        </div>
                     </div>

                     <div className="space-y-10">
                        <div className="flex items-center gap-4 text-blue-500">
                          <BarChart3 size={24} />
                          <h3 className="text-xl font-[1000] uppercase italic tracking-tighter">Vulnerability Intelligence</h3>
                        </div>
                        <div className="grid gap-6">
                           {selectedArtifact.findings?.map((f: any, i: number) => (
                             <div key={i} className="p-10 rounded-[3.5rem] bg-white/[0.02] border border-white/5 hover:border-blue-500/20 transition-all">
                                <div className="flex justify-between items-start mb-6">
                                   <h4 className="text-2xl font-black uppercase italic tracking-tighter text-white">{f.title}</h4>
                                   <span className={`px-5 py-1.5 rounded-full text-[9px] font-black uppercase tracking-widest ${f.severity === 'Critical' ? 'bg-rose-500/10 text-rose-500' : 'bg-amber-500/10 text-amber-500'}`}>{f.severity}</span>
                                </div>
                                <p className="text-slate-400 font-bold italic leading-relaxed mb-8">{f.description}</p>
                                <div className="p-8 bg-[#0B0E14] rounded-3xl border border-blue-500/10 font-mono text-[11px] text-blue-400 flex items-start gap-4">
                                   <span className="p-2 bg-blue-600 text-white rounded-lg text-[8px] font-black">FIX</span>
                                   {f.remediation}
                                </div>
                             </div>
                           ))}
                        </div>
                     </div>
                  </div>
                </>
              )}
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default ArchiveVault;