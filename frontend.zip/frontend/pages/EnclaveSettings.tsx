import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { 
  Shield, Zap, Lock, CreditCard, Building2, 
  ChevronRight, Crown, Loader2, Save, Key,
  ShieldCheck, RefreshCcw
} from 'lucide-react';

// Firebase Engine
import { db } from '../src/firebase';
import { doc, updateDoc } from 'firebase/firestore';

const EnclaveSettings = ({ orgData, workspaceId }: { orgData: any, workspaceId: string }) => {
  const [isUpdating, setIsUpdating] = useState(false);
  const [enclaveName, setEnclaveName] = useState(orgData?.name || '');

  // Logic: Plan Tiers as defined in the Protocol
  const PLANS = {
    'SOLO': { color: 'text-emerald-500', bg: 'bg-emerald-500/10', border: 'border-emerald-500/20' },
    'ALPHA': { color: 'text-blue-500', bg: 'bg-blue-600/10', border: 'border-blue-500/20' },
    'CORP': { color: 'text-purple-500', bg: 'bg-purple-600/10', border: 'border-purple-500/20' }
  };

  const currentPlan = (orgData?.planTier || 'ALPHA') as keyof typeof PLANS;

  const handleUpdateEnclave = async () => {
    if (!enclaveName) return;
    setIsUpdating(true);
    try {
      // Protocol: Update Metadata in Org Enclave
      await updateDoc(doc(db, 'organizations', workspaceId), {
        name: enclaveName
      });
      alert("Enclave Metadata Updated.");
    } catch (err) {
      console.error("Governance Error:", err);
    } finally {
      setIsUpdating(false);
    }
  };

  return (
    <div className="space-y-10">
      
      {/* 1. INFRASTRUCTURE OVERVIEW */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        {/* Plan Identity Card */}
        <motion.div initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }}
          className={`glass-card p-10 rounded-[3.5rem] border ${PLANS[currentPlan].border} bg-[#151921] relative overflow-hidden group`}>
          <div className="absolute top-0 right-0 p-8 opacity-5 group-hover:scale-110 transition-transform"><Crown size={80} /></div>
          <h4 className="text-[10px] font-black text-slate-500 uppercase tracking-[0.4em] mb-8">Infrastructure Tier</h4>
          <div className="space-y-2">
            <span className={`text-5xl font-[1000] italic tracking-tighter ${PLANS[currentPlan].color}`}>
              {orgData?.planTier || 'ALPHA'}
            </span>
            <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest flex items-center gap-2">
              <Zap size={12} className="text-amber-500" /> High-Performance Neural link
            </p>
          </div>
          <button className="w-full mt-10 py-4 bg-white/5 border border-white/5 rounded-2xl text-[9px] font-black uppercase tracking-widest text-slate-400 hover:bg-blue-600 hover:text-white transition-all flex items-center justify-center gap-2">
            Request Tier Upgrade <ChevronRight size={14} />
          </button>
        </motion.div>

        {/* Seat Governance Monitor */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}
          className="glass-card p-10 rounded-[3.5rem] border border-white/5 bg-[#151921]">
          <h4 className="text-[10px] font-black text-slate-500 uppercase tracking-[0.4em] mb-8 flex items-center gap-2">
            <Building2 size={14} /> Allocation Matrix
          </h4>
          <div className="space-y-6">
            <div className="flex justify-between items-end">
               <div>
                  <p className="text-4xl font-[1000] text-white italic tracking-tighter leading-none">
                    {orgData?.seatPolicy?.maxSeats || 0}
                  </p>
                  <p className="text-[9px] font-black text-slate-500 uppercase tracking-widest mt-2">Node Capacity</p>
               </div>
               <div className="text-right">
                  <p className="text-2xl font-black text-blue-500 italic tracking-tighter leading-none">
                    {orgData?.seatPolicy?.adminSeats || 1}
                  </p>
                  <p className="text-[9px] font-black text-slate-500 uppercase tracking-widest mt-2">Admin Slots</p>
               </div>
            </div>
            <div className="h-2 w-full bg-[#0B0E14] rounded-full overflow-hidden">
               <div className="h-full bg-blue-600 w-full opacity-30" />
            </div>
          </div>
        </motion.div>

        {/* Security Status */}
        <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }}
          className="glass-card p-10 rounded-[3.5rem] border border-emerald-500/10 bg-[#151921]">
          <h4 className="text-[10px] font-black text-emerald-500 uppercase tracking-[0.4em] mb-8 flex items-center gap-2">
            <ShieldCheck size={14} /> Enclave Protocol
          </h4>
          <div className="space-y-4">
             <div className="p-5 bg-emerald-500/5 rounded-2xl border border-emerald-500/10">
                <p className="text-[9px] font-bold text-emerald-500/70 uppercase leading-relaxed tracking-widest">
                  AES-256-GCM Hardware Encryption Active. All metadata artifacts are sealed at the Neural link level.
                </p>
             </div>
             <div className="flex items-center gap-3 px-4 py-3 bg-[#0B0E14] rounded-xl border border-white/5">
                <RefreshCcw size={12} className="text-slate-600" />
                <span className="text-[8px] font-black text-slate-600 uppercase tracking-widest">Auto-Rotate Enabled: 30 Days</span>
             </div>
          </div>
        </motion.div>
      </div>

      {/* 2. ENCLAVE IDENTITY CONFIGURATION */}
      <div className="grid grid-cols-1 xl:grid-cols-12 gap-10">
        <div className="xl:col-span-7 glass-card p-12 rounded-[4rem] border border-white/5 bg-[#151921]">
          <h3 className="text-2xl font-[1000] uppercase italic tracking-tighter text-white mb-10 leading-none">
            Identity <span className="text-blue-500">Configuration</span>
          </h3>
          
          <div className="space-y-8">
            <div className="space-y-3">
              <label className="text-[10px] font-black text-slate-500 uppercase tracking-[0.3em] ml-2">Enclave Artifact Name</label>
              <div className="relative">
                <Building2 className="absolute left-6 top-1/2 -translate-y-1/2 text-slate-600" size={20} />
                <input value={enclaveName} onChange={e => setEnclaveName(e.target.value)} placeholder="Enclave Name"
                  className="w-full bg-[#0B0E14] border border-white/5 py-6 pl-16 rounded-3xl font-bold text-sm text-white focus:border-blue-500 outline-none transition-all shadow-inner" />
              </div>
            </div>

            <button onClick={handleUpdateEnclave} disabled={isUpdating}
              className="px-10 py-5 bg-white text-black rounded-2xl font-black text-[10px] uppercase tracking-[0.2em] flex items-center gap-3 hover:bg-blue-600 hover:text-white transition-all active:scale-95">
              {isUpdating ? <Loader2 className="animate-spin" size={16} /> : <Save size={16} />} 
              Commit Identity Changes
            </button>
          </div>
        </div>

        {/* 3. NEURAL VAULT KEYS (Mock/Visual) */}
        <div className="xl:col-span-5 glass-card p-12 rounded-[4rem] border border-white/5 bg-[#0B0E14]">
          <h4 className="text-[10px] font-black text-slate-600 uppercase tracking-[0.4em] mb-10 flex items-center gap-2">
            <Lock size={14} /> Master Vault Access
          </h4>
          <div className="space-y-6">
            <div className="p-8 rounded-3xl bg-white/[0.02] border border-dashed border-white/5 flex flex-col items-center justify-center text-center">
               <Key size={32} className="text-slate-800 mb-4" />
               <p className="text-[9px] font-black text-slate-700 uppercase tracking-widest leading-relaxed">
                 Master Encryption Keys are isolated in the Secure Vault Partition. Physical backup recommended.
               </p>
               <button className="mt-6 text-[8px] font-black text-blue-500 uppercase tracking-[0.3em] hover:underline transition-all">
                 Rotate Keys Now
               </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default EnclaveSettings;