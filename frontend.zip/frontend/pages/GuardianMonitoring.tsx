import React, { useState, useEffect, useMemo } from 'react';
import { motion, AnimatePresence, Variants } from 'framer-motion';
import { 
  Activity, 
  Terminal as TerminalIcon, 
  ShieldAlert,
  Hash,
  Network,
  Moon,
  Sun,
  Lock,
  Wifi,
  Radio,
  Eye,
  Radar,
  Cpu,
  Globe,
  Zap,
  Waves
} from 'lucide-react';
import { 
  AreaChart, 
  Area, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer 
} from 'recharts';
import { SecurityLog } from '../types';

const generateMockLog = (mode: 'AGENT' | 'UPLINK'): SecurityLog => {
  const agentEvents = [
    'Memory segment parity check: OK',
    'Heuristic analyzer: 0.02ms latency',
    'Local stack frame encrypted',
    'System call hook validated',
    'Kernel level heartbeat synced',
    'Neural pattern matching synchronized'
  ];
  const uplinkEvents = [
    'TCP Handshake (SYN-ACK) @ Edge',
    'CDN Cache hit: /static/assets/core',
    'Cloud Logging stream synced (v4)',
    'Inbound packet scrubbed: PASS',
    'TLS 1.3 session handshake completed'
  ];
  const events = mode === 'AGENT' ? agentEvents : uplinkEvents;
  const sources = mode === 'AGENT' ? ['ENCLAVE-ALPHA', 'SENTINEL-X', 'NODE-LOCAL'] : ['EDGE-FRA-01', 'AWS-UPLINK', 'GCP-NODE'];
  const isThreat = Math.random() > 0.94;
  
  return {
    id: Math.random().toString(36).substr(2, 9),
    timestamp: new Date().toLocaleTimeString('en-GB', { hour12: false }),
    source: sources[Math.floor(Math.random() * sources.length)],
    event: isThreat ? 'BREACH_MITIGATED: Anomaly Neutralized' : events[Math.floor(Math.random() * events.length)],
    integrityHash: 'PRAD-' + Math.random().toString(36).substr(2, 4).toUpperCase() + '-H' + Math.floor(Math.random() * 100),
    status: isThreat ? 'Threat' : Math.random() > 0.9 ? 'Suspicious' : 'Clean'
  };
};

const GuardianMonitoring = () => {
  const [logs, setLogs] = useState<SecurityLog[]>([]);
  const [monitoringMode, setMonitoringMode] = useState<'AGENT' | 'UPLINK'>('AGENT');
  const [theme, setTheme] = useState<'dark' | 'light'>('dark');
  const [graphData, setGraphData] = useState<{ time: string, rps: number, threat: number }[]>([]);
  const [threatLevel, setThreatLevel] = useState(0);

  const containerVariants: Variants = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: { staggerChildren: 0.1, delayChildren: 0.1 }
    }
  };

  const itemVariants: Variants = {
    hidden: { opacity: 0, y: 30 },
    show: { opacity: 1, y: 0, transition: { duration: 0.8, ease: [0.16, 1, 0.3, 1] } }
  };

  useEffect(() => {
    const interval = setInterval(() => {
      const hasThreat = Math.random() > 0.9;
      setGraphData(prev => {
        const newData = [...prev, {
          time: new Date().toLocaleTimeString().split(' ')[0],
          rps: 200 + Math.sin(Date.now() / 1000) * 40 + (Math.random() * 20),
          threat: hasThreat ? 40 + Math.random() * 40 : 0
        }].slice(-25);
        return newData;
      });
      if (hasThreat) {
        setThreatLevel(100);
        setTimeout(() => setThreatLevel(0), 1000);
      }
    }, 800);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    setLogs([...Array(12)].map(() => generateMockLog(monitoringMode)));
    const interval = setInterval(() => {
      setLogs(prev => [generateMockLog(monitoringMode), ...prev.slice(0, 24)]);
    }, 1200);
    return () => clearInterval(interval);
  }, [monitoringMode]);

  useEffect(() => {
    document.body.setAttribute('data-theme', theme);
  }, [theme]);

  const stats = useMemo(() => [
    { label: 'Throughput', val: '2.84M', icon: Globe, color: 'blue' },
    { label: 'Anomalies', val: '12', icon: ShieldAlert, color: 'rose' },
    { label: 'Neural Latency', val: '1.2ms', icon: Cpu, color: 'emerald' },
  ], []);

  return (
    <div className="relative min-h-screen pb-20 overflow-x-hidden">
      <div className="fixed inset-0 cyber-grid-bg opacity-20 z-[-1]" />
      
      <motion.div 
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-8 mb-16"
      >
        <div className="space-y-2">
          <div className="flex items-center gap-3 text-[10px] font-black uppercase tracking-[0.4em] text-[var(--accent-primary)] mb-1">
            <Radio className="w-3.5 h-3.5 animate-pulse" /> Neural Core Active
          </div>
          <h1 className="text-6xl font-[900] text-[var(--text-primary)] tracking-tight uppercase leading-none italic">
            Neural <span className="neural-text-gradient">Pulse</span>
          </h1>
        </div>

        <div className="flex items-center gap-4">
          <div className="flex bg-[var(--card-bg)] backdrop-blur-3xl p-1 rounded-2xl border border-[var(--border-color)]">
            <button onClick={() => setMonitoringMode('AGENT')} className={`px-8 py-3 rounded-xl text-[10px] font-black uppercase transition-all ${monitoringMode === 'AGENT' ? 'bg-[var(--accent-primary)] text-white' : 'text-[var(--text-secondary)]'}`}>Agent</button>
            <button onClick={() => setMonitoringMode('UPLINK')} className={`px-8 py-3 rounded-xl text-[10px] font-black uppercase transition-all ${monitoringMode === 'UPLINK' ? 'bg-[var(--accent-primary)] text-white' : 'text-[var(--text-secondary)]'}`}>Uplink</button>
          </div>
          <button onClick={() => setTheme(t => t === 'dark' ? 'light' : 'dark')} className="p-4 glass-card rounded-2xl">
            {theme === 'dark' ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
          </button>
        </div>
      </motion.div>

      <motion.div variants={containerVariants} initial="hidden" animate="show" className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-start">
        <div className="lg:col-span-8 space-y-10">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {stats.map((stat, i) => (
              <motion.div key={i} variants={itemVariants} className="glass-card p-10 rounded-[3rem] relative overflow-hidden group">
                <div className={`p-4 bg-${stat.color}-500/10 text-${stat.color}-500 rounded-2xl w-fit mb-6`}><stat.icon className="w-8 h-8" /></div>
                <div className="text-[10px] font-black text-[var(--text-secondary)] uppercase tracking-[0.3em] mb-1">{stat.label}</div>
                <div className="text-5xl font-[900] text-[var(--text-primary)] tracking-tighter">{stat.val}</div>
              </motion.div>
            ))}
          </div>

          <motion.div variants={itemVariants} className="glass-card p-12 rounded-[4rem] relative overflow-hidden scanline-overlay min-h-[500px]">
            <div className="flex items-center justify-between mb-12">
               <div className="flex items-center gap-5">
                  <div className={`p-5 rounded-[1.75rem] transition-all duration-500 ${threatLevel > 0 ? 'bg-rose-500 text-white shadow-lg shadow-rose-500/30' : 'bg-[var(--accent-glow)] text-[var(--accent-primary)]'}`}>
                     <Waves className={`w-8 h-8 ${threatLevel > 0 ? 'animate-bounce' : 'animate-pulse'}`} />
                  </div>
                  <div>
                     <h3 className="text-3xl font-[900] uppercase tracking-tight italic">Fluid Telemetry</h3>
                     <p className="text-sm text-[var(--text-secondary)] font-medium">Real-time water wave smooth analog analysis.</p>
                  </div>
               </div>
               <div className="flex items-center gap-4">
                  <span className="w-3 h-3 rounded-full bg-[var(--accent-primary)] shadow-[0_0_10px_var(--accent-primary)]" />
                  <span className="text-[10px] font-black uppercase tracking-widest text-[var(--text-secondary)]">Neural Drift Optimized</span>
               </div>
            </div>

            <div className="h-[400px] w-full relative">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={graphData}>
                  <defs>
                    <linearGradient id="waveGradient" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="var(--accent-primary)" stopOpacity={0.4}/>
                      <stop offset="100%" stopColor="var(--accent-primary)" stopOpacity={0}/>
                    </linearGradient>
                    <filter id="analogGlow" x="-20%" y="-20%" width="140%" height="140%">
                      <feGaussianBlur stdDeviation="6" result="blur" />
                      <feComposite in="SourceGraphic" in2="blur" operator="over" />
                    </filter>
                  </defs>
                  <CartesianGrid strokeDasharray="5 5" vertical={false} stroke="var(--border-color)" opacity={0.3} />
                  <XAxis dataKey="time" hide />
                  <YAxis hide domain={[0, 300]} />
                  <Tooltip contentStyle={{ background: '#000', border: 'none', borderRadius: '1rem', color: '#fff' }} />
                  <Area 
                    type="monotone" 
                    dataKey="rps" 
                    stroke="var(--accent-primary)" 
                    strokeWidth={5} 
                    fill="url(#waveGradient)" 
                    filter="url(#analogGlow)"
                    animationDuration={1500}
                    animationEasing="ease-in-out"
                  />
                  <Area 
                    type="monotone" 
                    dataKey="threat" 
                    stroke="#f43f5e" 
                    strokeWidth={3} 
                    fill="transparent"
                  />
                </AreaChart>
              </ResponsiveContainer>
              {/* Liquid Wave Overlay Effect */}
              <div className="absolute inset-0 pointer-events-none opacity-10 bg-gradient-to-t from-transparent via-[var(--accent-primary)] to-transparent animate-pulse" />
            </div>
          </motion.div>
        </div>

        <motion.div variants={itemVariants} className="lg:col-span-4 lg:sticky lg:top-28">
          <div className="glass-card bg-[#0a0f1e] border-none rounded-[3.5rem] overflow-hidden flex flex-col h-[850px] shadow-2xl relative">
            <div className="px-12 py-10 border-b border-white/5 bg-white/[0.03] backdrop-blur-3xl flex items-center justify-between">
               <div className="flex items-center gap-5">
                  <div className="p-3.5 bg-blue-500/10 rounded-2xl relative">
                    <TerminalIcon className="w-7 h-7 text-[var(--accent-primary)]" />
                    <div className="absolute -top-1 -right-1 w-2.5 h-2.5 rounded-full bg-blue-500 animate-pulse" />
                  </div>
                  <div>
                    <span className="text-base font-black text-white uppercase tracking-[0.2em] block leading-none">Neural Ledger</span>
                    <span className="text-[10px] font-black text-[var(--accent-primary)] uppercase tracking-[0.3em] mt-2 flex items-center gap-2">
                       <Eye className="w-3.5 h-3.5" /> Active_Trace_v4.2
                    </span>
                  </div>
               </div>
            </div>

            <div className="flex-1 overflow-y-auto p-10 space-y-6 font-mono text-[11px] scrollbar-hide">
              <AnimatePresence mode="popLayout">
                {logs.map((log) => (
                  <motion.div
                    key={log.id}
                    layout
                    initial={{ opacity: 0, x: -30 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, scale: 0.9 }}
                    className={`p-6 rounded-[2rem] border transition-all ${log.status === 'Threat' ? 'bg-rose-500/20 border-rose-500/40' : 'bg-white/[0.04] border-white/5'}`}
                  >
                    <div className="flex items-center justify-between mb-3 opacity-40">
                      <span className="text-white">[{log.timestamp}]</span>
                      <span className="flex items-center gap-2 text-blue-400">
                        <Hash className="w-3.5 h-3.5" /> {log.integrityHash}
                      </span>
                    </div>
                    <div className="flex items-center gap-4 mb-2">
                      <span className="font-black uppercase tracking-widest text-blue-400">{log.source}</span>
                    </div>
                    <p className="text-slate-200 leading-relaxed">{log.event}</p>
                  </motion.div>
                ))}
              </AnimatePresence>
            </div>
            <div className="px-12 py-10 border-t border-white/5 bg-black/40 backdrop-blur-3xl flex items-center justify-between">
               <div className="flex items-center gap-4 text-[10px] font-black text-slate-500 uppercase tracking-widest">
                 <Lock className="w-4 h-4 text-emerald-500" /> SECURE_LEDGER.v4
               </div>
               <div className="w-2 h-2 rounded-full bg-[var(--success-color)] animate-pulse shadow-[0_0_10px_var(--success-color)]" />
            </div>
          </div>
        </motion.div>
      </motion.div>
    </div>
  );
};

export default GuardianMonitoring;