import { db } from '../src/firebase'; 
import { doc, setDoc, serverTimestamp } from 'firebase/firestore';

/**
 * ARCHITECTURAL NOTE: 
 * We use a Remote Bridge to encrypt sensitive metadata. This prevents the 
 * AES Master Key from being exposed in the browser's "Inspect Element".
 */
const API_URL = "http://localhost:8000";

const sealDataRemotely = async (data: string): Promise<string> => {
  try {
    const response = await fetch(`${API_URL}/api/utils/seal`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ data })
    });
    
    if (!response.ok) {
      const result = await response.json();
      throw new Error(result.error || "Encryption bridge rejected data.");
    }
    
    const result = await response.json();
    return result.sealed;
  } catch (error) {
    console.error("CRITICAL: Encryption Bridge Failure:", error);
    // In hackathon/production, we block account creation if security cannot be guaranteed.
    throw new Error("Security Protocol Failure: Could not seal metadata via Port 8000.");
  }
};

/* -------------------------------------------
   PLAN CONFIGURATION (Seat Governance)
   Determines the total number of allowed users.
------------------------------------------- */
const PLAN_LIMITS = {
  SOLO: { admins: 1, operators: 0, seats: 1, label: 'Personal Vault' },
  ALPHA: { admins: 1, operators: 10, seats: 11, label: 'Team Core' },
  CORP: { admins: 3, operators: 30, seats: 33, label: 'Enterprise Enclave' }
};

/**
 * initializeUserAccount
 * Verified Implementation: AES-256 Sealed RBAC & Ticket-Ready Infrastructure
 */
export const initializeUserAccount = async (
  uid: string,
  email: string,
  tier: 'SOLO' | 'ALPHA' | 'CORP',
  organizationName: string | null
) => {
  // Generate a unique Organization ID (Nexus ID)
  const orgId = `org_${Math.random().toString(36).substring(2, 10)}`;
  const limits = PLAN_LIMITS[tier];

  console.log(`[PRADYUMAN] Initializing Enclave for ${email} on ${tier} tier...`);

  try {
    // 1. CRYPTOGRAPHIC SEALING
    // Encrypt metadata before it ever touches the Database.
    const sealedOrgName = await sealDataRemotely(organizationName || 'PRADYUMAN_ENCLAVE');
    const sealedEmail = await sealDataRemotely(email);

    /* ---------------- PHASE A: USER IDENTITY (ROOT) ----------------
       CRITICAL: This must happen first to satisfy Firestore Rules.
    -----------------------------------------------------------------*/
    const userRef = doc(db, 'users', uid);
    await setDoc(userRef, {
      uid,
      sealedEmail, 
      organizationId: orgId,
      role: 'ADMIN', // First user is always the Enclave Admin
      createdAt: serverTimestamp(),
      profileComplete: true 
    });

    /* ---------------- PHASE B: ORGANIZATION ROOT ---------------- */
    const orgRef = doc(db, 'organizations', orgId);
    await setDoc(orgRef, {
      sealedName: sealedOrgName,
      planTier: tier,
      createdAt: serverTimestamp(),
      ownerUid: uid,
      status: 'ACTIVE_NODE',
      seatPolicy: {
        maxSeats: limits.seats,
        maxAdmins: limits.admins,
        maxOperators: limits.operators
      }
    });

    /* ---------------- PHASE C: ENCLAVE SUB-SYSTEMS ---------------- */
    
    // 1. Member Registry (Self-Enrollment)
    const memberRef = doc(db, `organizations/${orgId}/members`, uid);
    await setDoc(memberRef, {
      uid,
      sealedEmail,
      role: 'ADMIN',
      status: 'ACTIVE',
      joinedAt: serverTimestamp()
    });

    // 2. Ticket System Metadata
    const ticketMetaRef = doc(db, `organizations/${orgId}/meta`, 'tickets');
    await setDoc(ticketMetaRef, {
      totalRaised: 0,
      activeTasks: 0,
      lastUpdated: serverTimestamp()
    });

    // 3. Analytics & GRC Hub
    const analyticsRoot = doc(db, `organizations/${orgId}/meta`, 'analytics');
    await setDoc(analyticsRoot, {
      totalScans: 0,
      riskAverage: 10.0,
      complianceGrade: await sealDataRemotely('A') // Initial Grade
    });

    // 4. Scan Index (Vault Root)
    const scanIndexRef = doc(db, `organizations/${orgId}/scans`, '_index');
    await setDoc(scanIndexRef, {
      initialized: true,
      cryptoSealed: true, 
      createdAt: serverTimestamp()
    });

    console.log(`[PRADYUMAN] Enclave ${orgId} is now ONLINE.`);
    return { orgId };

  } catch (err: any) {
    console.error("ENCLAVE_INITIALIZATION_FAILED:", err);
    throw err;
  }
};