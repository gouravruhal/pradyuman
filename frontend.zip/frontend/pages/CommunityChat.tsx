import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { db, auth } from '../src/firebase';
import { 
  collection, query, orderBy, onSnapshot, addDoc, 
  serverTimestamp, updateDoc, doc, arrayUnion, arrayRemove, limit 
} from 'firebase/firestore';
import { 
  MessageSquare, Heart, Send, ShieldAlert, 
  Terminal, Zap, Fingerprint, Activity, Info
} from 'lucide-react';

const CommunityChat = ({ workspaceId }: { workspaceId: string }) => {
  const [messages, setMessages] = useState<any[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const scrollRef = useRef<HTMLDivElement>(null);
  const currentUserUid = auth.currentUser?.uid;

  useEffect(() => {
    if (!workspaceId) return;

    // Tactical Feed Query
    const q = query(
      collection(db, `organizations/${workspaceId}/messages`), 
      orderBy('timestamp', 'asc'),
      limit(100)
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const msgs = snapshot.docs.map(d => ({ id: d.id, ...d.data() }));
      setMessages(msgs);
      // Auto-scroll to latest tactical update
      setTimeout(() => scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: 'smooth' }), 100);
    });

    return () => unsubscribe();
  }, [workspaceId]);

  const sendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMessage.trim() || !auth.currentUser) return;

    try {
      await addDoc(collection(db, `organizations/${workspaceId}/messages`), {
        text: newMessage,
        sender: auth.currentUser.email?.split('@')[0] || 'Unknown_Node',
        uid: currentUserUid,
        type: 'HUMAN_INTEL',
        timestamp: serverTimestamp(),
        likes: []
      });
      setNewMessage('');
    } catch (err) {
      console.error("Uplink Failure:", err);
    }
  };

  return (
    <div className="bg-[#151921] border border-white/5 rounded-[3.5rem] overflow-hidden flex flex-col h-[800px] shadow-2xl relative">
      
      {/* Header: Tactical Context */}
      <div className="px-10 py-8 bg-white/[0.02] border-b border-white/5 flex justify-between items-center">
         <div className="flex items-center gap-4">
            <div className="p-3 bg-blue-600/10 rounded-xl">
               <Activity size={20} className="text-blue-500 animate-pulse" />
            </div>
            <div>
               <h4 className="text-sm font-black uppercase tracking-[0.3em] text-blue-500">Ops Channel</h4>
               <p className="text-[8px] font-bold text-slate-500 uppercase tracking-widest">Enclave_Communications_Secure</p>
            </div>
         </div>
         <div className="flex items-center gap-4 px-4 py-2 bg-emerald-500/5 border border-emerald-500/10 rounded-full">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-ping" />
            <span className="text-[9px] font-black text-emerald-500 uppercase tracking-widest">Neural Link: Active</span>
         </div>
      </div>

      {/* Feed Area */}
      <div ref={scrollRef} className="flex-1 overflow-y-auto p-10 space-y-8 bg-[#0B0E14]/30 scrollbar-hide">
        <AnimatePresence initial={false}>
          {messages.map((msg) => {
            const isMe = msg.uid === currentUserUid;
            const isSystem = msg.type !== 'HUMAN_INTEL';

            return (
              <motion.div 
                key={msg.id} 
                initial={{ opacity: 0, y: 10 }} 
                animate={{ opacity: 1, y: 0 }} 
                className={`flex flex-col ${isMe ? 'items-end' : 'items-start'}`}
              >
                {/* Message Meta */}
                <div className="flex items-center gap-3 mb-2 px-3">
                  <span className={`text-[8px] font-black uppercase tracking-widest ${isSystem ? 'text-blue-500' : 'text-slate-500'}`}>
                    {isSystem ? 'System_Event' : msg.sender}
                  </span>
                  {!isSystem && <div className="w-1 h-1 rounded-full bg-slate-800" />}
                  <span className="text-[8px] font-bold text-slate-700">
                    {msg.timestamp?.toDate().toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}
                  </span>
                </div>

                {/* Message Body */}
                <div className={`max-w-[80%] p-6 rounded-[2rem] border transition-all ${
                  isSystem 
                    ? 'bg-blue-600/5 border-blue-500/20 w-full' 
                    : isMe 
                      ? 'bg-blue-600 text-white border-transparent shadow-xl shadow-blue-600/10 rounded-tr-none' 
                      : 'bg-[#151921] border-white/5 text-slate-300 rounded-tl-none'
                }`}>
                  <div className="flex gap-4">
                    {isSystem && <Terminal className="text-blue-500 shrink-0" size={18} />}
                    <p className={`text-xs font-bold leading-relaxed ${isSystem ? 'italic text-blue-200' : ''}`}>
                      {msg.text}
                    </p>
                  </div>
                </div>

                {!isSystem && (
                  <button className="mt-3 flex items-center gap-2 px-3 py-1 rounded-full hover:bg-white/5 transition-colors text-[9px] font-black text-slate-500">
                    <Heart size={10} /> {(msg.likes || []).length}
                  </button>
                )}
              </motion.div>
            );
          })}
        </AnimatePresence>
      </div>

      {/* Input: Tactical Uplink */}
      <form onSubmit={sendMessage} className="p-8 bg-[#151921] border-t border-white/5 flex gap-4 items-center">
        <div className="flex-1 relative group">
           <Fingerprint className="absolute left-6 top-1/2 -translate-y-1/2 text-slate-600 group-focus-within:text-blue-500 transition-colors" size={18} />
           <input 
             value={newMessage} 
             onChange={(e) => setNewMessage(e.target.value)} 
             placeholder="Broadcast tactical intel to workspace..." 
             className="w-full bg-[#0B0E14] border border-white/5 pl-16 pr-6 py-5 rounded-2xl text-xs font-bold outline-none focus:border-blue-500/50 transition-all placeholder:text-slate-700" 
           />
        </div>
        <button 
          type="submit" 
          disabled={!newMessage.trim()} 
          className="p-5 bg-blue-600 text-white rounded-2xl hover:bg-blue-500 disabled:opacity-50 disabled:grayscale transition-all shadow-xl shadow-blue-600/20"
        >
          <Send size={20} />
        </button>
      </form>
    </div>
  );
};

export default CommunityChat;