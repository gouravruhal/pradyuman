import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { 
  Shield, Lock, Mail, ArrowRight, Loader2, 
  AlertCircle, Building2, User, Users, Check,
  RefreshCw, Fingerprint
} from 'lucide-react';

// Firebase Engine
import { auth, db } from '../src/firebase';
import { signInWithEmailAndPassword, createUserWithEmailAndPassword, signOut } from 'firebase/auth';
import { doc, getDoc } from 'firebase/firestore';

// Core Logic: Verified Implementation
import { initializeUserAccount } from './firebase_initialize';

const PLAN_TIERS = [
  { id: 'SOLO', label: 'Solo', icon: User, details: '1 Admin | 0 Operators', color: 'emerald' },
  { id: 'ALPHA', label: 'Alpha', icon: Users, details: '1 Admin | 10 Operators', color: 'blue' },
  { id: 'CORP', label: 'Corp', icon: Building2, details: '3 Admins | 30 Operators', color: 'purple' }
];

const LoginPage = () => {
  const [isLogin, setIsLogin] = useState(true);
  const [isVerifying, setIsVerifying] = useState(false);
  const [statusMsg, setStatusMsg] = useState('');
  const [error, setError] = useState<string | null>(null);

  // Form State
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [company, setCompany] = useState('');
  const [selectedTier, setSelectedTier] = useState<'SOLO' | 'ALPHA' | 'CORP'>('ALPHA');

  const navigate = useNavigate();

  // --- PROTECTION: Clear stale sessions on mount ---
  useEffect(() => {
    const clearStaleSession = async () => {
      if (auth.currentUser) await signOut(auth);
      localStorage.clear();
    };
    clearStaleSession();
  }, []);

  const handleAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setIsVerifying(true);

    try {
      let uid: string;

      if (isLogin) {
        // --- ACCESS FLOW (Existing User) ---
        setStatusMsg("Establishing Neural Link...");
        const cred = await signInWithEmailAndPassword(auth, email, password);
        uid = cred.user.uid;
      } else {
        // --- INITIALIZATION FLOW (New Admin) ---
        setStatusMsg("Initializing Node Artifact...");
        const cred = await createUserWithEmailAndPassword(auth, email, password);
        uid = cred.user.uid;

        setStatusMsg("Sealing Enclave Metadata...");
        // 1. Initialize DB with ADMIN role and Seat Policy
        await initializeUserAccount(uid, email, selectedTier, company);
      }

      // 2. VERIFY PERMISSIONS & LOAD CONTEXT
      // Wait for Firestore replication (Prevents Permission Denied on first read)
      setStatusMsg("Synchronizing RBAC Matrix...");
      await new Promise(r => setTimeout(r, 1000)); 

      const profileSnap = await getDoc(doc(db, 'users', uid));
      
      if (!profileSnap.exists()) {
        throw new Error("Security Protocol Failure: Node identity not found.");
      }

      const profile = profileSnap.data();
      
      // Store context for the rest of the app
      localStorage.setItem("orgId", profile.organizationId);
      localStorage.setItem("role", profile.role); 

      setStatusMsg("Connection Secure. Redirecting...");
      setTimeout(() => navigate('/dashboard'), 1000);

    } catch (err: any) {
      console.error("Auth Engine Error:", err);
      
      // Professional error mapping
      let msg = "Uplink Failed: Infrastructure rejected credentials.";
      if (err.message.includes('network-request-failed')) msg = "Neural Link Offline: Check backend status (Port 8000).";
      if (err.message.includes('insufficient-permissions')) msg = "Security Violation: Database rules rejected access.";
      if (err.message.includes('email-already-in-use')) msg = "Identity Conflict: Node ID already registered.";
      
      setError(msg);
      setIsVerifying(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#0B0E14] text-white flex items-center justify-center p-6 selection:bg-blue-500/30">
      
      {/* AUTH PROCESSING OVERLAY */}
      <AnimatePresence>
        {isVerifying && (
          <motion.div 
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} 
            className="fixed inset-0 z-[200] bg-[#0B0E14]/95 backdrop-blur-xl flex flex-col items-center justify-center"
          >
            <div className="relative">
              <RefreshCw className="w-20 h-20 text-blue-500 animate-spin opacity-20" />
              <Fingerprint className="w-10 h-10 text-blue-500 absolute inset-0 m-auto animate-pulse" />
            </div>
            <p className="text-blue-500 font-black tracking-[0.5em] uppercase text-[10px] mt-8 animate-pulse">
              {statusMsg}
            </p>
          </motion.div>
        )}
      </AnimatePresence>

      <div className={`w-full transition-all duration-700 ${isLogin ? 'max-w-lg' : 'max-w-3xl'}`}>
        <motion.div 
          layout
          initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} 
          className="bg-[#151921] rounded-[4rem] p-10 md:p-16 border border-white/5 shadow-2xl relative overflow-hidden"
        >
          {/* Ambient Glow */}
          <div className="absolute top-0 right-0 w-96 h-96 bg-blue-600/5 blur-[120px] rounded-full -mr-48 -mt-48" />

          <div className="text-center mb-16 relative z-10">
            <div className="p-5 bg-blue-600/10 rounded-3xl w-fit mx-auto mb-8 border border-blue-500/20">
              <Shield className="w-12 h-12 text-blue-500" />
            </div>
            <h1 className="text-5xl font-[1000] uppercase italic tracking-tighter leading-none">
              PRADYUMAN <span className="text-blue-500">{isLogin ? 'CORE' : 'NODE'}</span>
            </h1>
            <p className="text-slate-500 text-[10px] font-black uppercase tracking-[0.4em] mt-4">
              Autonomous Enclave Infrastructure // v4.2
            </p>
          </div>

          <form onSubmit={handleAuth} className="space-y-10 relative z-10">
            
            <AnimatePresence mode="wait">
              {!isLogin && (
                <motion.div 
                  initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }}
                  className="space-y-8"
                >
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    {PLAN_TIERS.map((tier) => (
                      <div 
                        key={tier.id}
                        onClick={() => setSelectedTier(tier.id as any)}
                        className={`cursor-pointer p-6 rounded-[2.5rem] border transition-all duration-500 flex flex-col items-center text-center gap-4 ${
                          selectedTier === tier.id 
                            ? `bg-blue-600/10 border-blue-500 shadow-2xl shadow-blue-500/10` 
                            : 'bg-[#0B0E14] border-white/5 opacity-40 hover:opacity-100 hover:border-white/10'
                        }`}
                      >
                        <tier.icon className={`w-6 h-6 ${selectedTier === tier.id ? 'text-blue-500' : 'text-slate-500'}`} />
                        <div className="space-y-1">
                          <p className="text-[10px] font-black uppercase tracking-widest text-white">{tier.label}</p>
                          <p className="text-[8px] text-slate-500 font-bold uppercase leading-tight">{tier.details}</p>
                        </div>
                        {selectedTier === tier.id && <Check className="text-blue-500" size={16} />}
                      </div>
                    ))}
                  </div>

                  <div className="relative group">
                    <Building2 className="absolute left-6 top-1/2 -translate-y-1/2 text-slate-600 group-focus-within:text-blue-500 transition-colors" size={20} />
                    <input 
                      required type="text" value={company} onChange={e => setCompany(e.target.value)} 
                      placeholder="Organization Name (Will be Sealed)"
                      className="w-full bg-[#0B0E14] border border-white/5 rounded-2xl py-6 pl-16 pr-6 font-bold text-sm focus:border-blue-500 outline-none transition-all placeholder:text-slate-700" 
                    />
                  </div>
                </motion.div>
              )}
            </AnimatePresence>

            <div className="space-y-4">
              <div className="relative group">
                <Mail className="absolute left-6 top-1/2 -translate-y-1/2 text-slate-600 group-focus-within:text-blue-500 transition-colors" size={20} />
                <input 
                  required type="email" value={email} onChange={e => setEmail(e.target.value)} 
                  placeholder="Enclave Identity (Email)"
                  className="w-full bg-[#0B0E14] border border-white/5 rounded-2xl py-6 pl-16 pr-6 font-bold text-sm focus:border-blue-500 outline-none transition-all placeholder:text-slate-700" 
                />
              </div>
              
              <div className="relative group">
                <Lock className="absolute left-6 top-1/2 -translate-y-1/2 text-slate-600 group-focus-within:text-blue-500 transition-colors" size={20} />
                <input 
                  required type="password" value={password} onChange={e => setPassword(e.target.value)} 
                  placeholder="Access Key"
                  className="w-full bg-[#0B0E14] border border-white/5 rounded-2xl py-6 pl-16 pr-6 font-bold text-sm focus:border-blue-500 outline-none transition-all placeholder:text-slate-700" 
                />
              </div>
            </div>

            {error && (
              <motion.div 
                initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} 
                className="flex items-center gap-4 text-rose-500 bg-rose-500/5 border border-rose-500/10 p-5 rounded-2xl"
              >
                <AlertCircle className="shrink-0" size={18} />
                <p className="text-[10px] font-black uppercase tracking-widest leading-relaxed">{error}</p>
              </motion.div>
            )}

            <button 
              type="submit" 
              className="w-full py-6 bg-blue-600 text-white rounded-[2rem] font-black uppercase tracking-[0.2em] text-[10px] flex items-center justify-center gap-4 hover:bg-blue-500 hover:scale-[1.02] active:scale-95 transition-all shadow-2xl shadow-blue-600/20"
            >
              {isLogin ? 'Request Uplink' : 'Initialize Node'} 
              <ArrowRight size={18} />
            </button>
          </form>

          <div className="mt-12 pt-10 border-t border-white/5 text-center">
            <button 
              onClick={() => { setIsLogin(!isLogin); setError(null); }} 
              className="text-slate-600 text-[10px] font-black uppercase tracking-[0.3em] hover:text-blue-500 transition-all"
            >
              {isLogin ? '// Register New Neural Artifact' : '// Access Authorized Portal'}
            </button>
          </div>
        </motion.div>

        <div className="mt-10 flex items-center justify-center gap-6 opacity-30">
           <div className="h-px w-12 bg-slate-700" />
           <p className="text-[8px] font-bold text-slate-500 uppercase tracking-[0.5em]">
             AES-256 GCM SECURED
           </p>
           <div className="h-px w-12 bg-slate-700" />
        </div>
      </div>
    </div>
  );
};

export default LoginPage;