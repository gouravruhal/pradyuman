
import React, { useRef } from 'react';
import { motion, useScroll, useTransform, useSpring } from 'framer-motion';
import { 
  User, Shield, Lock, Key, Globe, 
  Cpu, Zap, Fingerprint, Mail, Settings, LogOut,
  Camera, CheckCircle2, ChevronRight, Activity, Bug, History
} from 'lucide-react';

const ProfilePage = () => {
  const containerRef = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ["start start", "end end"]
  });

  const smoothProgress = useSpring(scrollYProgress, { 
    stiffness: 100, 
    damping: 30, 
    restDelta: 0.001 
  });

  // Avatar and text movement logic for scroll-driven effects
  const avatarScale = useTransform(smoothProgress, [0, 0.25], [1, 0.35]);
  const avatarX = useTransform(smoothProgress, [0, 0.25], [0, 450]); 
  const avatarY = useTransform(smoothProgress, [0, 0.25], [0, -90]);
  const textOpacity = useTransform(smoothProgress, [0, 0.2], [1, 0]);

  return (
    <div ref={containerRef} className="relative min-h-[250vh] -mt-28 pt-28 overflow-x-hidden">
      {/* Background Ambience */}
      <div className="fixed inset-0 pointer-events-none z-0">
        <div className="absolute top-1/4 -left-1/4 w-[800px] h-[800px] bg-blue-400/5 blur-[150px] rounded-full" />
      </div>

      {/* Main Profile Header - Slides from right + Scale up on load */}
      <motion.div 
        initial={{ x: 200, opacity: 0, scale: 0.8 }}
        animate={{ x: 0, opacity: 1, scale: 1 }}
        transition={{ duration: 1.2, ease: [0.16, 1, 0.3, 1] }}
        className="sticky top-28 z-[60] h-screen flex flex-col items-center justify-start pt-12 pointer-events-none"
      >
        <div className="pointer-events-auto flex flex-col items-center w-full max-w-7xl relative px-6">
          <motion.div style={{ scale: avatarScale, x: avatarX, y: avatarY }} className="relative mb-8">
            <div className="w-48 h-48 md:w-64 md:h-64 rounded-[3.5rem] bg-gradient-to-tr from-blue-600 to-indigo-600 p-1 shadow-2xl">
               <div className="w-full h-full rounded-[3.4rem] bg-white flex items-center justify-center overflow-hidden">
                  <User className="w-24 h-24 text-slate-100" />
               </div>
            </div>
            <motion.div 
              animate={{ scale: [1, 1.2, 1] }}
              transition={{ repeat: Infinity, duration: 2 }}
              className="absolute -bottom-4 -right-4 p-4 bg-emerald-500 rounded-2xl shadow-xl border-4 border-white"
            >
              <Shield className="w-6 h-6 text-white" />
            </motion.div>
          </motion.div>

          <motion.div style={{ opacity: textOpacity }} className="text-center space-y-4">
            <div className="flex items-center justify-center gap-3">
               <h1 className="text-6xl font-[900] text-slate-950 tracking-tighter uppercase italic leading-none">
                 Operator <span className="neural-text-gradient">Artifact</span>
               </h1>
               <motion.div 
                 animate={{ opacity: [0.3, 1, 0.3] }}
                 transition={{ duration: 1.5, repeat: Infinity }}
                 className="px-3 py-1 bg-emerald-500/10 border border-emerald-500/20 rounded-full flex items-center gap-2"
               >
                  <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 shadow-[0_0_8px_var(--success-color)]" />
                  <span className="text-[9px] font-black text-emerald-500 uppercase tracking-widest">Active Now</span>
               </motion.div>
            </div>
            <p className="text-slate-500 font-medium uppercase tracking-widest text-[11px] opacity-60">Rank: Senior Auditor • UID: PRAD-772-B12</p>
          </motion.div>
        </div>
      </motion.div>

      {/* Profile Detail Sections */}
      <div className="relative z-10 px-8 pb-32 mt-[-30vh] space-y-12 max-w-5xl mx-auto">
        <motion.div 
          initial={{ y: 50, opacity: 0 }}
          whileInView={{ y: 0, opacity: 1 }}
          transition={{ duration: 0.8 }}
          className="glass-card p-12 rounded-[3.5rem] grid grid-cols-1 md:grid-cols-3 gap-10"
        >
           {[
             { label: 'Total Scans', val: '142', Icon: Activity, color: 'blue' },
             { label: 'Threats Found', val: '28', Icon: Bug, color: 'rose' },
             { label: 'Data Handled', val: '8.4 GB', Icon: Zap, color: 'emerald' },
           ].map((stat, i) => (
             <div key={i} className="space-y-4">
                <div className={`p-4 bg-${stat.color}-500/10 text-${stat.color}-500 rounded-2xl w-fit`}>
                   <stat.Icon className="w-6 h-6" />
                </div>
                <div>
                  <p className="text-[10px] font-black uppercase tracking-widest text-slate-400 mb-1">{stat.label}</p>
                  <p className="text-4xl font-[900] text-slate-900">{stat.val}</p>
                </div>
             </div>
           ))}
        </motion.div>

        <motion.div 
          initial={{ y: 50, opacity: 0 }}
          whileInView={{ y: 0, opacity: 1 }}
          className="glass-card p-12 rounded-[3.5rem]"
        >
           <h3 className="text-2xl font-[900] uppercase tracking-tight mb-8 flex items-center gap-4">
             <History className="w-6 h-6 text-blue-600" /> Activity History
           </h3>
           <div className="space-y-6">
              {[
                { event: 'Neural Audit Executed', target: 'nexus.internal.ai', time: '2 hours ago' },
                { event: 'Vulnerability Mitigated', target: 'PRAD-XSS-04', time: '1 day ago' },
                { event: 'Policy Forge: ISO 27001', target: 'Corporate Policy v4', time: '3 days ago' },
              ].map((log, i) => (
                <div key={i} className="flex items-center justify-between p-6 rounded-2xl bg-white/5 border border-slate-100 group hover:border-blue-500/20 transition-all">
                   <div className="flex gap-6 items-center">
                      <div className="w-2 h-2 rounded-full bg-blue-500" />
                      <div>
                         <p className="text-sm font-black text-slate-900 uppercase tracking-tight">{log.event}</p>
                         <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">{log.target}</p>
                      </div>
                   </div>
                   <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{log.time}</span>
                </div>
              ))}
           </div>
        </motion.div>

        <motion.div 
          initial={{ y: 50, opacity: 0 }}
          whileInView={{ y: 0, opacity: 1 }}
          className="bg-slate-950 p-12 md:p-16 rounded-[4rem] text-white relative overflow-hidden"
        >
           <div className="absolute top-0 right-0 p-12 opacity-10"><Cpu className="w-64 h-64" /></div>
           <div className="relative z-10 space-y-8">
              <div className="inline-flex items-center gap-3 px-4 py-2 bg-blue-500/10 border border-blue-500/20 rounded-full text-blue-400 font-black text-[10px] uppercase tracking-widest">
                 <Fingerprint className="w-4 h-4" /> Hardware Locked Node
              </div>
              <h3 className="text-4xl font-[900] tracking-tighter uppercase italic leading-none">Identity Binding</h3>
              <p className="text-slate-400 font-medium max-w-2xl text-lg">Your operator identity artifact is cryptographically bound to this hardware node's TPM. Multi-factor authentication is active via the Enclave link.</p>
              <div className="flex items-center gap-8">
                 <button className="bg-blue-600 text-white px-10 py-5 rounded-[2rem] font-black uppercase text-[10px] tracking-widest shadow-xl shadow-blue-500/20 hover:scale-105 transition-all">Manage Keys</button>
                 <button className="text-[10px] font-black uppercase tracking-widest text-rose-500 hover:text-rose-400 transition-colors">Terminate All Sessions</button>
              </div>
           </div>
        </motion.div>
      </div>
    </div>
  );
};

export default ProfilePage;
