import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { BrainCircuit, Sparkles, Loader2, ShieldCheck, FileDown, FileText, Zap, Fingerprint } from 'lucide-react';

const API = "http://localhost:8000";

const PolicyForge = () => {
  const [isGenerating, setIsGenerating] = useState(false);
  const [companyIntel, setCompanyIntel] = useState('');
  const [framework, setFramework] = useState('ISO 27001');
  const [generatedPolicy, setGeneratedPolicy] = useState('');
  const [error, setError] = useState<string | null>(null);

  const handleForge = async () => {
    if (!companyIntel.trim()) return;
    
    setIsGenerating(true);
    setError(null);
    setGeneratedPolicy('');

    try {
      const res = await fetch(`${API}/api/ai/forge-policy`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          context: companyIntel, 
          framework: framework 
        })
      });

      if (!res.ok) {
        const errorData = await res.json();
        throw new Error(errorData.detail || "Neural synthesis rejected by backend.");
      }

      const data = await res.json();
      setGeneratedPolicy(data.policy);
    } catch (err: any) {
      console.error("Forge Link Failed:", err);
      setError(err.message || "Uplink Failure: Neural Engine Offline.");
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 min-h-[800px]">
      
      {/* 1. CONTROL PANEL */}
      <div className="lg:col-span-5">
        <div className="glass-card p-10 rounded-[3rem] border border-white/5 bg-[#151921]/60 h-full flex flex-col shadow-2xl">
          <div className="flex items-center gap-5 mb-10">
            <div className="p-3.5 bg-indigo-500/10 rounded-2xl border border-indigo-500/20">
              <BrainCircuit className="text-indigo-500" size={28} />
            </div>
            <div>
              <h3 className="text-2xl font-[1000] uppercase tracking-tighter text-white italic">Neural <span className="text-indigo-500">Forge</span></h3>
              <p className="text-[10px] text-slate-500 font-black uppercase tracking-widest">Autonomous Synthesis v4.5</p>
            </div>
          </div>

          <div className="space-y-8 flex-1">
            <div className="space-y-3">
              <label className="text-[9px] font-black text-slate-600 uppercase tracking-[0.4em] ml-2">Company DNA / Context</label>
              <textarea 
                placeholder="Describe your architecture (e.g., 'A FinTech startup using AWS and React with sensitive user PII')..."
                value={companyIntel}
                onChange={(e) => setCompanyIntel(e.target.value)}
                className="w-full h-80 bg-[#0B0E14] border border-white/5 rounded-[2.5rem] py-8 px-10 text-sm font-bold text-slate-300 focus:border-indigo-500/40 outline-none transition-all resize-none shadow-inner placeholder:opacity-30"
              />
            </div>

            <div className="space-y-3">
              <label className="text-[9px] font-black text-slate-600 uppercase tracking-[0.4em] ml-2">Target Framework</label>
              <select value={framework} onChange={(e) => setFramework(e.target.value)} 
                className="w-full bg-[#0B0E14] border border-white/5 rounded-2xl py-6 px-8 text-[10px] font-[1000] uppercase tracking-[0.2em] text-indigo-400 outline-none cursor-pointer appearance-none hover:border-indigo-500/30 transition-all">
                <option>ISO 27001 (Security)</option>
                <option>ISO 42001 (AI Ethics)</option>
                <option>NIST Cybersecurity</option>
                <option>SOC2 Compliance</option>
              </select>
            </div>

            <button onClick={handleForge} disabled={!companyIntel || isGenerating} 
              className="w-full py-7 bg-indigo-600 text-white rounded-[2.5rem] font-[1000] uppercase tracking-[0.3em] text-[10px] flex items-center justify-center gap-4 shadow-2xl shadow-indigo-600/20 disabled:opacity-30 hover:bg-indigo-500 hover:scale-[1.02] active:scale-95 transition-all">
              {isGenerating ? <Loader2 className="animate-spin" size={18} /> : <Zap size={18} />}
              {isGenerating ? 'Synthesizing Intelligence...' : 'FORGE ARTIFACT'}
            </button>

            {error && (
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="p-4 bg-rose-500/5 border border-rose-500/20 rounded-2xl text-[9px] font-black text-rose-500 uppercase tracking-widest text-center">
                {error}
              </motion.div>
            )}
          </div>
        </div>
      </div>

      {/* 2. ARTIFACT PREVIEW */}
      <div className="lg:col-span-7 relative">
        <div className="glass-card bg-[#0B0E14]/50 p-16 rounded-[4rem] h-full overflow-y-auto border border-white/5 relative border-t-8 border-indigo-500/40 shadow-2xl backdrop-blur-3xl">
          <AnimatePresence mode="wait">
            {generatedPolicy ? (
              <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-10">
                 <div className="border-b border-white/5 pb-8 mb-10 flex justify-between items-end">
                    <div>
                      <h2 className="text-4xl font-[1000] uppercase italic tracking-tighter text-white leading-none">Neural <span className="text-indigo-500">Artifact</span></h2>
                      <p className="text-[8px] font-black text-slate-600 uppercase tracking-[0.4em] mt-3">Enclave Verified Ledger // GRC-SMART</p>
                    </div>
                    <div className="text-right hidden sm:block">
                      <p className="text-[8px] font-black text-slate-700 uppercase tracking-widest leading-none mb-1">Status</p>
                      <p className="text-[10px] font-bold text-emerald-500 flex items-center gap-2 uppercase italic">
                        <ShieldCheck size={12} /> Authenticated
                      </p>
                    </div>
                 </div>
                 <div className="whitespace-pre-wrap text-slate-400 text-sm font-bold leading-loose selection:bg-indigo-500/30">
                   {generatedPolicy}
                 </div>
                 <div className="pt-12 border-t border-white/5 flex justify-between items-center opacity-30">
                    <p className="text-[8px] font-black uppercase tracking-[0.5em]">Pradyuman ShaaS Protocol</p>
                    <Fingerprint size={24} />
                 </div>
              </motion.div>
            ) : (
              <div className="flex flex-col items-center justify-center h-full opacity-5 space-y-10">
                <FileText size={160} className="text-slate-400" />
                <p className="text-5xl font-[1000] uppercase italic tracking-widest text-center leading-tight">Forge<br/>Idle</p>
              </div>
            )}
          </AnimatePresence>
        </div>
        
        {generatedPolicy && (
          <motion.button initial={{ scale: 0 }} animate={{ scale: 1 }} 
            className="absolute bottom-10 right-10 bg-indigo-600 text-white p-6 rounded-full shadow-2xl hover:scale-110 active:scale-90 transition-all z-[70] group border border-indigo-400/20">
            <FileDown className="w-8 h-8 group-hover:translate-y-1 transition-transform" />
          </motion.button>
        )}
      </div>
    </div>
  );
};

export default PolicyForge;