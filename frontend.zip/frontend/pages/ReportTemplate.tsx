import React, { forwardRef } from 'react';
import { Shield, Clock, Hash, Globe, Mail, Building2, Terminal } from 'lucide-react';

interface Finding {
  id: string; title: string; severity: string; description: string; remediation: string; score: number;
}

interface Props {
  target: string; findings: Finding[]; aiSummary: string | null; reportId: string; timestamp: string; mail: string;
}

const ReportTemplate = forwardRef<HTMLDivElement, Props>(({ target, findings, aiSummary, reportId, timestamp, mail }, ref) => {
  const org = "Panipat Institute of Engineering and Technology";
  const score = Math.max(0, 10 - (findings.length * 1.5)).toFixed(1);

  return (
    <div ref={ref} className="bg-white text-black p-12 w-[210mm] min-h-[297mm] font-sans">
      {/* Header Area */}
      <div className="flex justify-between items-start border-b-4 border-black pb-8 mb-10">
        <div>
          <h1 className="text-4xl font-black uppercase tracking-tighter italic">Shield-as-a-Service</h1>
          <p className="text-xs font-bold tracking-[0.2em] text-gray-500 mt-1 uppercase">Official Security Audit Manifest</p>
          <p className="text-sm font-black mt-4">{org}</p>
        </div>
        <div className="text-right space-y-1 text-[10px] font-mono font-bold uppercase">
          <p>ID: {reportId}</p>
          <p>Date: {timestamp}</p>
        </div>
      </div>

      {/* Identity Grid */}
      <div className="grid grid-cols-2 gap-6 mb-12">
        <div className="p-4 bg-gray-50 border border-gray-200 rounded-xl">
          <p className="text-[8px] font-black uppercase text-gray-400 mb-1">Target Endpoint</p>
          <p className="text-xs font-bold truncate">{target}</p>
        </div>
        <div className="p-4 bg-gray-50 border border-gray-200 rounded-xl">
          <p className="text-[8px] font-black uppercase text-gray-400 mb-1">Scanner Authority</p>
          <p className="text-xs font-bold">{mail}</p>
        </div>
      </div>

      {/* Score Summary */}
      <div className="bg-black text-white p-8 rounded-3xl mb-12 flex items-center justify-between">
        <div className="max-w-md">
          <h2 className="text-lg font-black uppercase tracking-widest mb-2 italic underline decoration-blue-500">Executive Analysis</h2>
          <p className="text-xs leading-relaxed opacity-80">"{aiSummary || "Audit complete. Vulnerabilities detected require immediate remediation."}"</p>
        </div>
        <div className="text-center border-l border-white/20 pl-8">
          <p className="text-[8px] font-black uppercase mb-1 tracking-widest">GRC Score</p>
          <p className="text-5xl font-black text-blue-400">{score}</p>
        </div>
      </div>

      {/* Vulnerability Catalog */}
      <div className="space-y-6">
        <h3 className="text-sm font-black uppercase tracking-[0.3em] border-b pb-2">Identified Vulnerabilities</h3>
        {findings.map((f, i) => (
          <div key={i} className="border border-gray-100 p-6 rounded-2xl page-break-inside-avoid shadow-sm">
            <div className="flex justify-between items-start mb-4">
              <span className={`text-[8px] px-3 py-1 rounded-full font-black uppercase ${f.severity === 'Critical' ? 'bg-red-100 text-red-600' : 'bg-orange-100 text-orange-600'}`}>
                {f.severity} RISK
              </span>
              <span className="text-[10px] font-mono text-gray-400">FINDING #{f.id}</span>
            </div>
            <h4 className="text-xl font-black uppercase italic mb-3">{f.title}</h4>
            <div className="grid grid-cols-2 gap-6 text-[11px]">
              <div>
                <p className="font-black uppercase text-gray-400 mb-1 tracking-widest">Impact Analysis</p>
                <p className="italic leading-relaxed">{f.description}</p>
              </div>
              <div>
                <p className="font-black uppercase text-blue-500 mb-1 tracking-widest">Remediation Path</p>
                <p className="bg-gray-50 p-3 rounded-lg border border-gray-100 font-mono text-[9px]">{f.remediation}</p>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Footer */}
      <div className="mt-12 pt-8 border-t text-[8px] font-bold text-gray-400 flex justify-between items-center uppercase tracking-widest">
        <p>© 2026 Shield-as-a-Service | PIET Cyber-Intelligence Lab</p>
        <p>Confidential Scan Report</p>
      </div>
    </div>
  );
});

export default ReportTemplate;