import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Fingerprint, ShieldAlert, Loader2, Lock } from 'lucide-react';

// Firebase Protocol
import { db } from '../src/firebase';
import { collection, onSnapshot, doc, query, orderBy } from 'firebase/firestore';

// Modular Child Components
import NodeManager from './NodeManager';
import TicketSystem from './ticketSystem'; // Ensure casing matches your file name
import EnclaveSettings from './EnclaveSettings';

const OrganizationControlPlane = ({ workspaceId }: { workspaceId: string }) => {
  const [activeTab, setActiveTab] = useState<'NODES' | 'TICKETS' | 'SETTINGS'>('NODES');
  
  // Intelligence State
  const [members, setMembers] = useState<any[]>([]);
  const [orgData, setOrgData] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  
  // RBAC Matrix
  const userRole = localStorage.getItem("role"); 
  const isManagement = userRole === 'ADMIN';

  // ---------------------------------------------------------
  // REAL-TIME DATA SYNCHRONIZATION
  // ---------------------------------------------------------
  useEffect(() => {
    if (!workspaceId) return;

    // 1. Sync Enclave Hierarchy (Members)
    const unsubMembers = onSnapshot(collection(db, `organizations/${workspaceId}/members`), (snap) => {
      // Logic Fix: Map ID explicitly to resolve 'key' prop warnings
      setMembers(snap.docs.map(d => ({ id: d.id, ...d.data() })));
    });

    // 2. Sync Enclave Metadata (Plan/Governance)
    const unsubOrg = onSnapshot(doc(db, 'organizations', workspaceId), (snap) => {
      if (snap.exists()) {
        setOrgData(snap.data());
      }
      setLoading(false);
    });

    return () => { 
      unsubMembers(); 
      unsubOrg(); 
    };
  }, [workspaceId]);

  if (loading) {
    return (
      <div className="h-[60vh] flex flex-col items-center justify-center space-y-4">
        <Loader2 className="w-12 h-12 text-blue-500 animate-spin opacity-20" />
        <p className="text-[10px] font-black text-blue-500 uppercase tracking-[0.5em] animate-pulse">Synchronizing Enclave...</p>
      </div>
    );
  }

  return (
    <div className="space-y-12 max-w-[1600px] mx-auto pb-32 px-6">
      
      {/* --- C2 COMMAND HEADER --- */}
      <div className="flex flex-col lg:flex-row justify-between items-start lg:items-end gap-10 border-b border-white/5 pb-12">
        <div className="space-y-5">
          <div className="flex items-center gap-4">
            <div className="bg-blue-600 text-white px-4 py-1.5 rounded-xl text-[10px] font-black uppercase tracking-widest flex items-center gap-2 shadow-xl shadow-blue-600/20">
              <Fingerprint size={14} /> {orgData?.planTier || 'ENCLAVE'} NODE
            </div>
            <div className="flex items-center gap-2 px-3 py-1 bg-white/5 rounded-lg border border-white/10">
              <Lock size={10} className="text-slate-500" />
              <span className="text-[9px] font-bold text-slate-500 uppercase tracking-widest">NEXUS: {workspaceId}</span>
            </div>
          </div>
          <h1 className="text-7xl font-[1000] uppercase italic tracking-tighter leading-none text-white">
            Command <span className="text-blue-500 text-glow">Center</span>
          </h1>
        </div>

        {/* --- NAVIGATION MATRIX --- */}
        <div className="flex p-2 bg-[#151921] border border-white/5 rounded-[2.5rem] shadow-2xl relative z-10">
          {['NODES', 'TICKETS', 'SETTINGS'].map((tab) => (
            <button 
              key={tab}
              onClick={() => setActiveTab(tab as any)}
              className={`px-12 py-4 rounded-[2rem] text-[10px] font-black uppercase tracking-widest transition-all duration-300
                ${activeTab === tab 
                  ? 'bg-blue-600 text-white shadow-2xl shadow-blue-600/40' 
                  : 'text-slate-500 hover:text-white hover:bg-white/5'
                }`}
            >
              {tab}
            </button>
          ))}
        </div>
      </div>

      {/* --- DYNAMIC SECTOR DISPLAY --- */}
      <AnimatePresence mode="wait">
        <motion.div 
          key={activeTab} 
          initial={{ opacity: 0, y: 15 }} 
          animate={{ opacity: 1, y: 0 }} 
          exit={{ opacity: 0, y: -15 }}
          transition={{ duration: 0.4, ease: "circOut" }}
        >
          {activeTab === 'NODES' && (
            <NodeManager 
              workspaceId={workspaceId} 
              isManagement={isManagement} 
              members={members} 
              orgData={orgData} 
            />
          )}

          {activeTab === 'TICKETS' && (
            <TicketSystem 
              workspaceId={workspaceId} 
              isManagement={isManagement} 
            />
          )}

          {activeTab === 'SETTINGS' && (
            isManagement ? (
              <EnclaveSettings orgData={orgData} workspaceId={workspaceId} />
            ) : (
              <div className="py-32 flex flex-col items-center justify-center border-2 border-dashed border-white/5 rounded-[4rem] opacity-20">
                <ShieldAlert size={64} className="mb-6" />
                <p className="text-sm font-[1000] uppercase italic tracking-tighter">Governance Partition Locked</p>
                <p className="text-[9px] font-black uppercase tracking-[0.4em] mt-2">Security Clearance Required</p>
              </div>
            )
          )}
        </motion.div>
      </AnimatePresence>

      {/* FOOTER TELEMETRY */}
      <div className="fixed bottom-10 left-1/2 -translate-x-1/2 hidden lg:flex items-center gap-8 px-10 py-4 bg-[#0B0E14]/80 backdrop-blur-xl border border-white/5 rounded-full z-50 shadow-2xl">
         <div className="flex items-center gap-3">
            <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
            <span className="text-[9px] font-black text-slate-500 uppercase tracking-widest">Enclave Status: Hardened</span>
         </div>
         <div className="w-px h-4 bg-white/10" />
         <div className="flex items-center gap-3">
            <span className="text-[9px] font-black text-slate-500 uppercase tracking-widest">Operator: {userRole}</span>
         </div>
      </div>
    </div>
  );
};

export default OrganizationControlPlane;